@echo off
SETLOCAL

:: ----------------------------
:: Check Python Installation
:: ----------------------------
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo Python is not installed.
    echo Please install the latest version of Python from https://www.python.org/downloads/
    pause
    exit /b
) ELSE (
    echo Python is installed.
)

:: Get Python version
FOR /F "tokens=2 delims= " %%A IN ('python --version') DO SET PYVER=%%A
echo Detected Python version: %PYVER%

:: Optionally: check if Python >= 3.x
SET MAJOR_VER=%PYVER:~0,1%
IF %MAJOR_VER% LSS 3 (
    echo Your Python version is outdated. Please update to the latest Python version.
    pause
    exit /b
)

:: ----------------------------
:: Ensure pip is installed
:: ----------------------------
python -m ensurepip --upgrade
python -m pip install --upgrade pip

:: ----------------------------
:: Install / Update Packages
:: ----------------------------
echo Installing/updating required packages...
python -m pip install --upgrade requests beautifulsoup4 "web3[eth-account]" pywin32 cryptography faker

echo All required packages are installed and up to date.
pause
ENDLOCAL