#!/usr/bin/env python3
"""
Fake Bitcoin Auto-Checker & Drainer
------------------------------------
A tkinter-based fake UI that auto-generates credit card numbers, checks them,
and if a card is "valid", it automatically drains its balance.
For educational/entertainment purposes only.
"""

import tkinter as tk
from tkinter import ttk
import random
import datetime

# ---------- Card Generation Helpers ----------
def luhn_checksum(card_number: int) -> int:
    """Compute Luhn checksum for a card number (without check digit)."""
    def digits_of(n):
        return [int(d) for d in str(n)]
    digits = digits_of(card_number)
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    total = sum(odd_digits)
    for d in even_digits:
        total += sum(digits_of(d * 2))
    return total % 10

def generate_card():
    """Generate a fake credit card (Visa-like), expiry, and CVV."""
    digits = [random.randint(0, 9) for _ in range(15)]
    number_without_check = int(''.join(map(str, digits))) * 10
    check_digit = (10 - luhn_checksum(number_without_check)) % 10
    digits.append(check_digit)
    card_str = ''.join(map(str, digits))
    formatted = ' '.join(card_str[i:i+4] for i in range(0, 16, 4))

    now = datetime.datetime.now()
    current_year = now.year % 100
    month = random.randint(1, 12)
    year = random.randint(current_year, current_year + 5)
    exp = f"{month:02d}/{year:02d}"

    cvv = f"{random.randint(0, 999):03d}"

    return {
        'number': formatted,
        'last4': card_str[-4:],
        'exp': exp,
        'cvv': cvv
    }

# ---------- Main Application ----------
class AutoCardCheckerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BTC Auto-Checker & Drainer")
        self.root.resizable(False, False)
        self.root.configure(bg='black')

        # Control flags
        self.running = False
        self.state = "idle"          # "idle", "checking", "draining"
        self.after_ids = []

        # Data for valid cards (displayed in treeview)
        # each entry: {'card': masked number, 'balance': float, 'drained': float, 'status': str}
        self.valid_cards = []

        # Setup styles (dark theme)
        self._setup_styles()

        # Build UI
        self._create_widgets()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('.', background='black', foreground='lime',
                        fieldbackground='black', bordercolor='darkgreen',
                        lightcolor='darkgreen', darkcolor='darkgreen')
        style.configure('TButton', background='darkgreen', foreground='lime',
                        focuscolor='none', borderwidth=2, relief='raised')
        style.map('TButton', background=[('active', 'green')])
        style.configure('TLabel', background='black', foreground='lime')
        style.configure('TFrame', background='black')
        style.configure('Treeview', background='black', foreground='lime',
                        fieldbackground='black', borderwidth=1)
        style.configure('Treeview.Heading', background='darkgreen', foreground='lime')

    def _create_widgets(self):
        mainframe = ttk.Frame(self.root, padding="10")
        mainframe.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Control buttons
        btn_frame = ttk.Frame(mainframe)
        btn_frame.grid(row=0, column=0, columnspan=2, pady=(0,10), sticky=tk.W)

        self.start_btn = ttk.Button(btn_frame, text="▶ Start Auto", command=self.start_auto)
        self.start_btn.pack(side=tk.LEFT, padx=2)

        self.stop_btn = ttk.Button(btn_frame, text="■ Stop", command=self.stop_auto, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=2)

        self.withdraw_btn = ttk.Button(btn_frame, text="💸 Manual Withdraw", command=self.manual_withdraw)
        self.withdraw_btn.pack(side=tk.LEFT, padx=2)

        self.clear_btn = ttk.Button(btn_frame, text="🗑 Clear Log", command=self.clear_log)
        self.clear_btn.pack(side=tk.LEFT, padx=2)

        # Treeview for valid cards
        tree_frame = ttk.Frame(mainframe)
        tree_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.tree = ttk.Treeview(tree_frame, columns=('card', 'status', 'drained', 'balance'),
                                 show='headings', height=6)
        self.tree.heading('card', text='Card (last 4)')
        self.tree.heading('status', text='Status')
        self.tree.heading('drained', text='Drained ($)')
        self.tree.heading('balance', text='Balance ($)')
        self.tree.column('card', width=120)
        self.tree.column('status', width=80)
        self.tree.column('drained', width=100)
        self.tree.column('balance', width=100)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH)

        scroll_tree = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        scroll_tree.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.configure(yscrollcommand=scroll_tree.set)

        # Log text widget
        log_frame = ttk.Frame(mainframe)
        log_frame.grid(row=2, column=0, columnspan=2, pady=5, sticky=(tk.W, tk.E))

        self.log_text = tk.Text(log_frame, width=70, height=15, bg='black', fg='lime',
                                insertbackground='lime', borderwidth=2, relief='sunken',
                                font=('Courier', 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH)

        scroll_log = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        scroll_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.configure(yscrollcommand=scroll_log.set)

        # Progress bar for effect
        self.progress = ttk.Progressbar(mainframe, orient=tk.HORIZONTAL, length=400,
                                        mode='indeterminate', style='TProgressbar')
        self.progress.grid(row=3, column=0, columnspan=2, pady=5)

        # Status label
        self.status_var = tk.StringVar(value="Idle. Press Start to begin.")
        status_label = ttk.Label(mainframe, textvariable=self.status_var)
        status_label.grid(row=4, column=0, columnspan=2, sticky=tk.W)

    # ---------- Logging ----------
    def log(self, message, color='lime'):
        """Insert a timestamped message into the log with optional color."""
        timestamp = datetime.datetime.now().strftime('%H:%M:%S')
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n", (color,))
        self.log_text.tag_config(color, foreground=color)
        self.log_text.see(tk.END)

    def clear_log(self):
        self.log_text.delete(1.0, tk.END)

    # ---------- Control ----------
    def start_auto(self):
        if self.running:
            return
        self.running = True
        self.state = "checking"
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start(10)
        self.log("Auto-check started. Scanning for valid cards...", 'cyan')
        self.status_var.set("Auto-checking...")
        self._schedule_check(1000)   # start after 1 sec

    def stop_auto(self):
        if not self.running:
            return
        self.running = False
        self.state = "idle"
        # Cancel all pending after calls
        for after_id in self.after_ids:
            self.root.after_cancel(after_id)
        self.after_ids.clear()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress.stop()
        self.log("Auto-check stopped by user.", 'orange')
        self.status_var.set("Stopped.")

    def _schedule_check(self, delay_ms):
        if not self.running or self.state != "checking":
            return
        after_id = self.root.after(delay_ms, self._generate_and_check)
        self.after_ids.append(after_id)

    def _generate_and_check(self):
        if not self.running or self.state != "checking":
            return
        # Generate a new card
        card = generate_card()
        self.log(f"Generated card: **** **** **** {card['last4']} | EXP: {card['exp']} CVV: {card['cvv']}", 'white')

        # Simulate validity check: 5% chance of being valid
        is_valid = random.random() < 0.05
        if is_valid:
            self.log(f"✅ Card **** **** **** {card['last4']} is VALID! Initializing drain...", 'lime')
            self.state = "draining"
            # Assign a random balance to this card
            balance = round(random.uniform(100, 5000), 2)
            card_data = {
                'card': f"**** **** **** {card['last4']}",
                'balance': balance,
                'drained': 0.0,
                'status': 'Active',
                'exp': card['exp'],
                'cvv': card['cvv'],
                'steps': random.randint(3, 8)   # number of drain steps
            }
            self.valid_cards.append(card_data)
            self._update_treeview()
            self.log(f"💰 Card balance: ${balance:.2f}. Draining in {card_data['steps']} steps...", 'yellow')
            self._drain_step(card_data)
        else:
            self.log(f"❌ Card **** **** **** {card['last4']} invalid (declined).", 'red')
            # Schedule next check
            self._schedule_check(800)

    # ---------- Draining ----------
    def _drain_step(self, card_data):
        if not self.running or self.state != "draining":
            return
        if card_data['balance'] <= 0 or card_data['steps'] <= 0:
            self._finish_drain(card_data)
            return

        # Withdraw a random amount (up to 50% of remaining balance)
        max_withdraw = min(card_data['balance'], card_data['balance'] * 0.5)
        withdraw = round(random.uniform(10, max_withdraw), 2)
        card_data['balance'] -= withdraw
        card_data['drained'] += withdraw
        card_data['steps'] -= 1

        self.log(f"💸 Withdrew ${withdraw:.2f} from **** **** **** {card_data['card'][-4:]}. Remaining: ${card_data['balance']:.2f}", 'lightgreen')
        self._update_treeview()

        if card_data['balance'] <= 0 or card_data['steps'] <= 0:
            self._finish_drain(card_data)
        else:
            # Schedule next drain step after 1-2 seconds
            delay = random.randint(1000, 2000)
            after_id = self.root.after(delay, lambda: self._drain_step(card_data))
            self.after_ids.append(after_id)

    def _finish_drain(self, card_data):
        if card_data['balance'] <= 0:
            card_data['status'] = 'Drained (empty)'
            self.log(f"🏁 Card **** **** **** {card_data['card'][-4:]} fully drained! Total extracted: ${card_data['drained']:.2f}", 'magenta')
        else:
            card_data['status'] = 'Drained (partial)'
            self.log(f"⏹ Card **** **** **** {card_data['card'][-4:]} drain stopped. Total extracted: ${card_data['drained']:.2f}, remaining: ${card_data['balance']:.2f}", 'magenta')

        self._update_treeview()
        # Resume checking
        self.state = "checking"
        self._schedule_check(1500)

    def _update_treeview(self):
        # Clear tree
        for row in self.tree.get_children():
            self.tree.delete(row)
        # Insert all valid cards
        for card in self.valid_cards:
            self.tree.insert('', tk.END, values=(
                card['card'],
                card['status'],
                f"${card['drained']:.2f}",
                f"${card['balance']:.2f}"
            ))

    # ---------- Manual Withdraw ----------
    def manual_withdraw(self):
        """Manually trigger a withdrawal on the last valid active card (if any)."""
        # Find the most recent active card
        active_cards = [c for c in self.valid_cards if c['status'] == 'Active']
        if not active_cards:
            self.log("No active card to withdraw from.", 'orange')
            return
        # Use the last active card (the one most recently added)
        card_data = active_cards[-1]
        self.log(f"Manual withdrawal triggered on card {card_data['card']}.", 'yellow')
        # If currently draining, we interrupt? Better to queue a withdrawal.
        # We'll just do one step regardless of state.
        if self.state == "draining":
            self.log("Auto-drain in progress; manual withdrawal may interfere.", 'orange')
        # Perform a single withdrawal step
        if card_data['balance'] <= 0:
            self.log("Card already empty.", 'orange')
            return
        max_withdraw = min(card_data['balance'], card_data['balance'] * 0.5)
        withdraw = round(random.uniform(10, max_withdraw), 2)
        card_data['balance'] -= withdraw
        card_data['drained'] += withdraw
        self.log(f"💸 Manual withdrawal: ${withdraw:.2f} from {card_data['card']}. Remaining: ${card_data['balance']:.2f}", 'lightgreen')
        if card_data['balance'] <= 0:
            card_data['status'] = 'Drained (empty)'
            self.log(f"🏁 Card {card_data['card']} now empty.", 'magenta')
        self._update_treeview()

# ---------- Run the application ----------
if __name__ == "__main__":
    root = tk.Tk()
    app = AutoCardCheckerApp(root)
    root.mainloop()