import tkinter as tk
from tkinter import ttk, scrolledtext, simpledialog, messagebox
import threading
import queue
import random
import string
import time
from datetime import datetime

# ----------------------------- Configuration ----------------------------- #
COINS = {
    "BITCOIN":    {"symbol": "BTC", "color": "orange", "price_usd": 50000.0},
    "ETHEREUM":   {"symbol": "ETH", "color": "light blue", "price_usd": 3000.0},
    "DOGECOIN":   {"symbol": "DOGE", "color": "yellow", "price_usd": 0.1},
    "SOLANA":     {"symbol": "SOL", "color": "purple", "price_usd": 100.0},
    "LITECOIN":   {"symbol": "LTC", "color": "silver", "price_usd": 150.0}
}
DEFAULT_COIN = "BITCOIN"
HASH_LENGTH = 64
SLEEP_TIME = 0.085                # delay between hash generations
FIND_PROBABILITY = 0.001           # 0.1% chance per hash to find something
MIN_FIND_AMOUNT = 0.001
MAX_FIND_AMOUNT = 0.1
SECRET_FIND_USD = 1000.0           # when you press 'k'
MAX_DISPLAY_LINES = 1000

# Colors for tags
COLOR_SYMBOL = "green"
COLOR_HASH_FIND = "gold"           # when a find occurs
COLOR_HASH_NOFIND = "red"
COLOR_BALANCE = "green"
COLOR_ART = "black"                 # now black
COLOR_LOG_COIN = "light blue"

# ----------------------------- Main Application -------------------------- #
class ArtemisMinerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Artemis Miner")
        self.root.geometry("1200x700")
        self.root.minsize(900, 500)

        # Control variables
        self.mining_active = threading.Event()
        self.selected_coin = tk.StringVar(value=DEFAULT_COIN)
        self.current_price = COINS[DEFAULT_COIN]["price_usd"]
        self.hash_count = 0
        self.balance = 0.0
        self.total_finds = 0
        self.total_found_amount = 0.0
        self.count_lock = threading.Lock()
        self.balance_lock = threading.Lock()
        self.message_queue = queue.Queue()

        # Bind coin change to update price and balance display
        self.selected_coin.trace('w', self._on_coin_change)

        # Build GUI
        self._create_widgets()
        self._configure_tags()

        # Start queue polling
        self._poll_queue()

        # Bind secret key
        self.root.bind('<Key-k>', self._secret_find)

        # Handle window close gracefully
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------------------------------------------------------------- #
    # GUI Creation
    # ---------------------------------------------------------------------- #
    def _create_widgets(self):
        """Create all GUI elements."""
        # Top frame: ASCII art (black)
        art_frame = ttk.Frame(self.root)
        art_frame.pack(fill=tk.X, padx=10, pady=(10, 0))

        ascii_art = r"""
░█████╗░██████╗░████████╗███████╗███╗░░░███╗██╗░██████╗  ███╗░░░███╗██╗███╗░░██╗███████╗██████╗░
██╔══██╗██╔══██╗╚══██╔══╝██╔════╝████╗░████║██║██╔════╝  ████╗░████║██║████╗░██║██╔════╝██╔══██╗
███████║██████╔╝░░░██║░░░█████╗░░██╔████╔██║██║╚█████╗░  ██╔████╔██║██║██╔██╗██║█████╗░░██████╔╝
██╔══██║██╔══██╗░░░██║░░░██╔══╝░░██║╚██╔╝██║██║░╚═══██╗  ██║╚██╔╝██║██║██║╚████║██╔══╝░░██╔══██╗
██║░░██║██║░░██║░░░██║░░░███████╗██║░╚═╝░██║██║██████╔╝  ██║░╚═╝░██║██║██║░╚███║███████╗██║░░██║
╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═╝░░░░░╚═╝╚═╝╚═════╝░  ╚═╝░░░░░╚═╝╚═╝╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝
"""
        art_label = tk.Label(art_frame, text=ascii_art, font=("Courier New", 8),
                             fg=COLOR_ART, justify=tk.LEFT)
        art_label.pack()

        # Control frame (coin selection, buttons, stats)
        control_frame = ttk.LabelFrame(self.root, text="Controls", padding=10)
        control_frame.pack(fill=tk.X, padx=10, pady=10)

        # Row 0: coin selection and main buttons
        ttk.Label(control_frame, text="Select coin:").grid(row=0, column=0, padx=(0,5), sticky=tk.W)
        coin_menu = ttk.Combobox(control_frame, textvariable=self.selected_coin,
                                 values=list(COINS.keys()), state="readonly", width=15)
        coin_menu.grid(row=0, column=1, padx=(0,20), sticky=tk.W)

        self.start_stop_btn = ttk.Button(control_frame, text="Start Mining",
                                         command=self._toggle_mining, width=15)
        self.start_stop_btn.grid(row=0, column=2, padx=(0,10))

        ttk.Button(control_frame, text="Clear Output",
                   command=self._clear_output, width=15).grid(row=0, column=3, padx=(0,20))

        ttk.Button(control_frame, text="Withdraw",
                   command=self._withdraw, width=15).grid(row=0, column=4, padx=(0,10))

        # Row 1: stats
        self.counter_label = ttk.Label(control_frame, text="Total hashes: 0")
        self.counter_label.grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=(10,0))

        self.balance_label = ttk.Label(control_frame, text="")  # will be set later
        self.balance_label.grid(row=1, column=2, columnspan=2, sticky=tk.W, pady=(10,0))

        self.avg_find_label = ttk.Label(control_frame, text="Avg find: 0.0000")
        self.avg_find_label.grid(row=1, column=4, sticky=tk.W, pady=(10,0))

        # Configure grid weights
        for i in range(5):
            control_frame.columnconfigure(i, weight=0)
        control_frame.columnconfigure(5, weight=1)   # spacer

        # Notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))

        # Tab 1: Mining Output
        mining_frame = ttk.Frame(self.notebook)
        self.notebook.add(mining_frame, text="Mining Output")
        self.output_text = scrolledtext.ScrolledText(
            mining_frame, wrap=tk.NONE, font=("Consolas", 10),
            bg="black", fg="white", insertbackground="white"
        )
        self.output_text.pack(fill=tk.BOTH, expand=True)
        self.output_text.config(state=tk.DISABLED)

        # Tab 2: Find Log
        log_frame = ttk.Frame(self.notebook)
        self.notebook.add(log_frame, text="Find Log")
        self.log_text = scrolledtext.ScrolledText(
            log_frame, wrap=tk.NONE, font=("Consolas", 9),
            bg="#1e1e1e", fg="white", insertbackground="white"
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.config(state=tk.DISABLED)

        # Configure log tags
        self.log_text.tag_config("timestamp", foreground="gray")
        self.log_text.tag_config("coin", foreground=COLOR_LOG_COIN)
        self.log_text.tag_config("amount", foreground="gold")
        self.log_text.tag_config("withdraw", foreground="red")

        # Initial balance display
        self._update_balance_display()

    def _configure_tags(self):
        """Create text tags for coloured output."""
        self.output_text.tag_config("symbol", foreground=COLOR_SYMBOL)
        self.output_text.tag_config("hash_find", foreground=COLOR_HASH_FIND)
        self.output_text.tag_config("hash_nofind", foreground=COLOR_HASH_NOFIND)
        self.output_text.tag_config("balance", foreground=COLOR_BALANCE)

    # ---------------------------------------------------------------------- #
    # Helper: Update balance label with crypto and USD
    # ---------------------------------------------------------------------- #
    def _update_balance_display(self):
        """Refresh the balance label with crypto amount and USD equivalent."""
        crypto_amount = self.balance
        usd_value = crypto_amount * self.current_price
        self.balance_label.config(text=f"Balance: {crypto_amount:.4f} {COINS[self.selected_coin.get()]['symbol']} (${usd_value:.2f})")

    def _on_coin_change(self, *args):
        """Called when the selected coin changes."""
        coin = self.selected_coin.get()
        self.current_price = COINS[coin]["price_usd"]
        self._update_balance_display()

    # ---------------------------------------------------------------------- #
    # Mining Thread Control
    # ---------------------------------------------------------------------- #
    def _toggle_mining(self):
        """Start or stop the mining thread."""
        if self.mining_active.is_set():
            self.mining_active.clear()
            self.start_stop_btn.config(text="Start Mining")
        else:
            self.mining_active.set()
            self.start_stop_btn.config(text="Stop Mining")
            miner_thread = threading.Thread(target=self._mining_loop, daemon=True)
            miner_thread.start()

    def _mining_loop(self):
        """
        Background thread that generates fake hashes.
        Randomly decides if a find occurs and puts messages into the queue.
        """
        coin = self.selected_coin.get()
        symbol = COINS[coin]["symbol"]

        while self.mining_active.is_set():
            # Generate random hash
            hash_str = ''.join(random.choices(string.ascii_letters + string.digits, k=HASH_LENGTH))

            # Determine if this hash yields a find
            if random.random() < FIND_PROBABILITY:
                amount = random.uniform(MIN_FIND_AMOUNT, MAX_FIND_AMOUNT)
                line = f"> {symbol} | {hash_str} | +{amount:.4f}\n"
            else:
                amount = 0.0
                line = f"> {symbol} | {hash_str} | 0.00\n"

            self.message_queue.put(("line", line, coin, amount))

            with self.count_lock:
                self.hash_count += 1
            self.message_queue.put(("count", self.hash_count))

            if amount > 0:
                timestamp = datetime.now().strftime("%H:%M:%S")
                self.message_queue.put(("log", timestamp, coin, amount))

            time.sleep(SLEEP_TIME)

    # ---------------------------------------------------------------------- #
    # GUI Updates (main thread)
    # ---------------------------------------------------------------------- #
    def _poll_queue(self):
        """Check the queue for new messages and update the GUI accordingly."""
        try:
            while True:
                msg = self.message_queue.get_nowait()
                if msg[0] == "line":
                    _, line, coin, amount = msg
                    self._insert_line(line, coin, amount)
                    if amount > 0:
                        self._update_balance(amount)
                elif msg[0] == "count":
                    _, count = msg
                    self.counter_label.config(text=f"Total hashes: {count}")
                elif msg[0] == "log":
                    _, timestamp, coin, amount = msg
                    self._add_log_entry(timestamp, coin, amount)
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self._poll_queue)

    def _insert_line(self, line, coin, amount):
        """Insert a coloured line into the output widget."""
        self.output_text.config(state=tk.NORMAL)

        sym_end = line.find(" |") + 2
        hash_start = sym_end
        hash_end = line.find(" |", hash_start)
        balance_start = hash_end

        self.output_text.insert(tk.END, line)

        self.output_text.tag_add("symbol", f"end-{len(line)}c", f"end-{len(line)+sym_end}c")

        hash_tag = "hash_find" if amount > 0 else "hash_nofind"
        self.output_text.tag_add(hash_tag,
                                 f"end-{len(line)+hash_start}c",
                                 f"end-{len(line)+hash_end}c")

        self.output_text.tag_add("balance",
                                 f"end-{len(line)+balance_start}c",
                                 "end-1c")

        self.output_text.see(tk.END)
        self._trim_output()
        self.output_text.config(state=tk.DISABLED)

    def _trim_output(self):
        lines = int(self.output_text.index('end-1c').split('.')[0])
        if lines > MAX_DISPLAY_LINES:
            self.output_text.config(state=tk.NORMAL)
            self.output_text.delete("1.0", f"{lines - MAX_DISPLAY_LINES}.0")
            self.output_text.config(state=tk.DISABLED)

    def _update_balance(self, amount):
        """Update balance and average find stats."""
        with self.balance_lock:
            self.balance += amount
            self.total_finds += 1
            self.total_found_amount += amount
            avg = self.total_found_amount / self.total_finds if self.total_finds > 0 else 0

        # Update GUI
        self._update_balance_display()
        self.avg_find_label.config(text=f"Avg find: {avg:.4f}")

    def _add_log_entry(self, timestamp, coin, amount):
        """Insert a formatted entry into the log widget."""
        self.log_text.config(state=tk.NORMAL)

        self.log_text.insert(tk.END, f"[{timestamp}] ", "timestamp")
        self.log_text.insert(tk.END, f"{coin}: ", "coin")
        self.log_text.insert(tk.END, f"+{amount:.4f}\n", "amount")

        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    # ---------------------------------------------------------------------- #
    # User Actions
    # ---------------------------------------------------------------------- #
    def _clear_output(self):
        """Clear the mining output."""
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete("1.0", tk.END)
        self.output_text.config(state=tk.DISABLED)

    def _withdraw(self):
        """Prompt for wallet address and reset balance to zero."""
        address = simpledialog.askstring("Withdraw",
                                         f"Enter your {COINS[self.selected_coin.get()]['symbol']} wallet address:",
                                         parent=self.root)
        if address is None:  # cancelled
            return
        if not address.strip():
            messagebox.showwarning("Invalid Address", "Address cannot be empty.")
            return

        # Withdraw the current balance
        with self.balance_lock:
            withdrawn_amount = self.balance
            self.balance = 0.0
            self.total_finds = 0
            self.total_found_amount = 0.0

        # Update balance display
        self._update_balance_display()
        self.avg_find_label.config(text="Avg find: 0.0000")

        # Log the withdrawal
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"[{timestamp}] WITHDRAWAL: ", "withdraw")
        self.log_text.insert(tk.END, f"{withdrawn_amount:.4f} {COINS[self.selected_coin.get()]['symbol']} ", "amount")
        self.log_text.insert(tk.END, f"to {address[:12]}...\n", "timestamp")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    def _secret_find(self, event=None):
        """Secret key 'k' – instantly add $1000 worth of the current coin."""
        coin = self.selected_coin.get()
        symbol = COINS[coin]["symbol"]
        price = COINS[coin]["price_usd"]
        amount = SECRET_FIND_USD / price  # convert USD to crypto

        # Create a special line in the output
        line = f"> {symbol} | {'#'*HASH_LENGTH} | +{amount:.4f} (SECRET FIND!)\n"
        self._insert_line(line, coin, amount)

        # Update balance and log
        self._update_balance(amount)
        timestamp = datetime.now().strftime("%H:%M:%S")
        self._add_log_entry(timestamp, coin, amount)

    # ---------------------------------------------------------------------- #
    # Cleanup
    # ---------------------------------------------------------------------- #
    def _on_close(self):
        self.mining_active.clear()
        self.root.destroy()


# ----------------------------- Entry Point ------------------------------- #
if __name__ == "__main__":
    root = tk.Tk()
    app = ArtemisMinerApp(root)
    root.mainloop()