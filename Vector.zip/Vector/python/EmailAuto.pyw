import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import threading
import time
import re
from datetime import datetime
import json
import os
import ssl

class EmailAutomater:
    def __init__(self, root):
        self.root = root
        self.root.title("Email Automater")
        self.root.geometry("700x750")
        
        # Variables
        self.schedule_running = False
        self.scheduler_thread = None
        self.interval_seconds = 0  # Added missing attribute
        
        # Set up config directory
        self.config_dir = os.path.expanduser("~/.email_automater")
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)
        self.config_file = os.path.join(self.config_dir, "config.json")
        
        # Load saved configuration
        self.config = self.load_config()
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill='both', expand=True)
        
        # Notebook for tabs
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill='both', expand=True)
        
        # Email Configuration Tab
        config_frame = ttk.Frame(notebook, padding=10)
        notebook.add(config_frame, text="Email Configuration")
        
        # Sender Email
        ttk.Label(config_frame, text="Your Email:").grid(row=0, column=0, sticky='w', pady=5)
        self.sender_email = ttk.Entry(config_frame, width=40)
        self.sender_email.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        self.sender_email.insert(0, self.config.get('sender_email', ''))
        
        # Password
        ttk.Label(config_frame, text="App Password:").grid(row=1, column=0, sticky='w', pady=5)
        self.password = ttk.Entry(config_frame, width=40, show="*")
        self.password.grid(row=1, column=1, padx=5, pady=5, sticky='ew')
        self.password.insert(0, self.config.get('password', ''))
        
        # SMTP Server
        ttk.Label(config_frame, text="SMTP Server:").grid(row=2, column=0, sticky='w', pady=5)
        self.smtp_server = ttk.Entry(config_frame, width=40)
        self.smtp_server.grid(row=2, column=1, padx=5, pady=5, sticky='ew')
        self.smtp_server.insert(0, self.config.get('smtp_server', 'smtp.gmail.com'))
        
        # SMTP Port
        ttk.Label(config_frame, text="SMTP Port:").grid(row=3, column=0, sticky='w', pady=5)
        self.smtp_port = ttk.Entry(config_frame, width=40)
        self.smtp_port.grid(row=3, column=1, padx=5, pady=5, sticky='ew')
        self.smtp_port.insert(0, self.config.get('smtp_port', '587'))
        
        # Test connection button
        ttk.Button(config_frame, text="Test Connection", command=self.test_connection).grid(row=4, column=0, columnspan=2, pady=10)
        
        # Save config button
        ttk.Button(config_frame, text="Save Configuration", command=self.save_config).grid(row=5, column=0, columnspan=2, pady=5)
        
        # Email Content Tab
        content_frame = ttk.Frame(notebook, padding=10)
        notebook.add(content_frame, text="Email Content")
        
        # Recipient Email
        ttk.Label(content_frame, text="Recipient Email:").grid(row=0, column=0, sticky='w', pady=5)
        self.recipient_email = ttk.Entry(content_frame, width=40)
        self.recipient_email.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        self.recipient_email.insert(0, self.config.get('recipient_email', ''))
        
        # Subject
        ttk.Label(content_frame, text="Subject:").grid(row=1, column=0, sticky='w', pady=5)
        self.subject = ttk.Entry(content_frame, width=40)
        self.subject.grid(row=1, column=1, padx=5, pady=5, sticky='ew')
        self.subject.insert(0, self.config.get('subject', 'Automated Email'))
        
        # Email Body
        ttk.Label(content_frame, text="Message Body:").grid(row=2, column=0, sticky='nw', pady=5)
        self.body = scrolledtext.ScrolledText(content_frame, width=40, height=10)
        self.body.grid(row=2, column=1, padx=5, pady=5, sticky='nsew')
        if 'body' in self.config:
            self.body.insert('1.0', self.config['body'])
        else:
            self.body.insert('1.0', 'Hello,\n\nThis is an automated email.\n\nBest regards,\nEmail Automater')
        
        # Schedule Tab
        schedule_frame = ttk.Frame(notebook, padding=10)
        notebook.add(schedule_frame, text="Schedule")
        
        # Interval Scheduling Options
        ttk.Label(schedule_frame, text="Send every:").grid(row=0, column=0, sticky='w', pady=5)
        
        self.interval_value = tk.StringVar(value=self.config.get('interval_value', '1'))
        interval_val_spin = ttk.Spinbox(schedule_frame, from_=1, to=60, width=5, textvariable=self.interval_value)
        interval_val_spin.grid(row=0, column=1, padx=5, pady=5, sticky='w')
        
        self.interval_unit = tk.StringVar(value=self.config.get('interval_unit', 'minutes'))
        interval_unit_combo = ttk.Combobox(schedule_frame, textvariable=self.interval_unit, 
                                          values=["seconds", "minutes", "hours"], state="readonly", width=10)
        interval_unit_combo.grid(row=0, column=2, padx=5, pady=5, sticky='w')
        
        # Start/Stop buttons
        button_frame = ttk.Frame(schedule_frame)
        button_frame.grid(row=1, column=0, columnspan=3, pady=20)
        
        self.start_button = ttk.Button(button_frame, text="Start Automation", command=self.start_automation)
        self.start_button.pack(side='left', padx=5)
        
        self.stop_button = ttk.Button(button_frame, text="Stop Automation", command=self.stop_automation, state='disabled')
        self.stop_button.pack(side='left', padx=5)
        
        # Test button
        self.test_button = ttk.Button(button_frame, text="Send Test Email", command=self.send_test_email)
        self.test_button.pack(side='left', padx=5)
        
        # Status
        self.status_var = tk.StringVar()
        self.status_var.set("Status: Ready")
        status_label = ttk.Label(schedule_frame, textvariable=self.status_var)
        status_label.grid(row=2, column=0, columnspan=3, pady=10)
        
        # Next send time
        self.next_send_var = tk.StringVar()
        self.next_send_var.set("Next send: Not scheduled")
        next_send_label = ttk.Label(schedule_frame, textvariable=self.next_send_var)
        next_send_label.grid(row=3, column=0, columnspan=3, pady=5)
        
        # Log
        ttk.Label(schedule_frame, text="Activity Log:").grid(row=4, column=0, sticky='w', pady=5)
        self.log = scrolledtext.ScrolledText(schedule_frame, width=60, height=10, state='disabled')
        self.log.grid(row=5, column=0, columnspan=3, padx=5, pady=5, sticky='nsew')
        
        # Help section
        help_frame = ttk.Frame(notebook, padding=10)
        notebook.add(help_frame, text="Help")
        
        help_text = """
        Email Automater Help:
        
        1. Email Configuration:
           - For Gmail, use 'smtp.gmail.com' and port '587'
           - You need to generate an 'App Password' instead of using your regular password
           - To generate an App Password: 
             - Enable 2-factor authentication on your Google account
             - Go to Security settings > App passwords
             - Generate a password for this application
        
        2. Scheduling:
           - Select how often to send emails (seconds, minutes, or hours)
           - Click Start Automation to begin
        
        3. Common Issues:
           - "Username and Password not accepted" error: 
             You're probably using your regular password instead of an App Password
        
        Note: This application stores your configuration in:
        """ + self.config_dir
        
        help_label = scrolledtext.ScrolledText(help_frame, width=70, height=20, wrap=tk.WORD)
        help_label.insert('1.0', help_text)
        help_label.config(state='disabled')
        help_label.pack(fill='both', expand=True)
        
        # Configure grid weights
        config_frame.columnconfigure(1, weight=1)
        content_frame.columnconfigure(1, weight=1)
        content_frame.rowconfigure(2, weight=1)
        schedule_frame.columnconfigure(2, weight=1)
        schedule_frame.rowconfigure(5, weight=1)
        
    def log_message(self, message):
        """Add a message to the log with timestamp"""
        self.log.config(state='normal')
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log.insert('end', f"[{timestamp}] {message}\n")
        self.log.see('end')
        self.log.config(state='disabled')
        
    def validate_email(self, email):
        """Simple email validation"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
            
    def test_connection(self):
        """Test SMTP connection without sending an email"""
        sender = self.sender_email.get()
        password = self.password.get()
        smtp_server = self.smtp_server.get()
        
        try:
            smtp_port = int(self.smtp_port.get())
        except ValueError:
            self.log_message("Error: SMTP port must be a number")
            messagebox.showerror("Error", "SMTP port must be a number")
            return
            
        if not all([sender, password, smtp_server]):
            self.log_message("Error: Email, password and SMTP server are required")
            messagebox.showerror("Error", "Email, password and SMTP server are required")
            return
            
        if not self.validate_email(sender):
            self.log_message("Error: Invalid email format")
            messagebox.showerror("Error", "Invalid email format")
            return
            
        self.log_message("Testing SMTP connection...")
        
        try:
            # Use regular connection with STARTTLS
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(sender, password)
            server.quit()
            self.log_message("SMTP connection successful!")
            messagebox.showinfo("Success", "SMTP connection test successful!")
        except Exception as e:
            error_msg = str(e)
            self.log_message(f"SMTP connection failed: {error_msg}")
            
            # Provide more user-friendly error messages
            if "535" in error_msg or "Username and Password not accepted" in error_msg:
                messagebox.showerror("Authentication Error", 
                    "Username and password not accepted. For Gmail, you must:\n\n"
                    "1. Enable 2-factor authentication\n"
                    "2. Generate an App Password (not your regular password)\n"
                    "3. Use that App Password in this application\n\n"
                    "See the Help tab for detailed instructions.")
            elif "connection refused" in error_msg.lower():
                messagebox.showerror("Connection Error", 
                    "Connection refused. Please check:\n\n"
                    "1. Your SMTP server and port settings\n"
                    "2. Your internet connection\n"
                    "3. Your firewall settings")
            else:
                messagebox.showerror("Error", f"SMTP connection failed: {error_msg}")
            
    def send_email(self):
        """Send an email with the current configuration"""
        try:
            # Get values from UI
            sender = self.sender_email.get()
            password = self.password.get()
            recipient = self.recipient_email.get()
            subject = self.subject.get()
            body = self.body.get('1.0', 'end-1c')
            smtp_server = self.smtp_server.get()
            
            try:
                smtp_port = int(self.smtp_port.get())
            except ValueError:
                self.log_message("Error: SMTP port must be a number")
                return False
                
            # Validate inputs
            if not all([sender, password, recipient, subject, body, smtp_server]):
                self.log_message("Error: All fields are required")
                return False
                
            if not self.validate_email(sender):
                self.log_message("Error: Invalid sender email format")
                return False
                
            if not self.validate_email(recipient):
                self.log_message("Error: Invalid recipient email format")
                return False
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = recipient
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Connect to server and send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(sender, password)
            text = msg.as_string()
            server.sendmail(sender, recipient, text)
            server.quit()
            
            self.log_message(f"Email sent successfully to {recipient}")
            return True
            
        except Exception as e:
            self.log_message(f"Error sending email: {str(e)}")
            return False
            
    def update_next_send_time(self):
        """Update the next scheduled send time display"""
        if not self.schedule_running:
            self.next_send_var.set("Next send: Not scheduled")
            return
            
        # Calculate next send time
        interval_value = int(self.interval_value.get())
        interval_unit = self.interval_unit.get()
        
        if interval_unit == "seconds":
            next_time = datetime.now().timestamp() + interval_value
        elif interval_unit == "minutes":
            next_time = datetime.now().timestamp() + (interval_value * 60)
        else:  # hours
            next_time = datetime.now().timestamp() + (interval_value * 3600)
            
        next_time_str = datetime.fromtimestamp(next_time).strftime("%Y-%m-%d %H:%M:%S")
        self.next_send_var.set(f"Next send: {next_time_str}")
            
    def send_test_email(self):
        """Send a test email"""
        self.log_message("Sending test email...")
        if self.send_email():
            messagebox.showinfo("Success", "Test email sent successfully!")
        else:
            messagebox.showerror("Error", "Failed to send test email. Check the log for details.")
            
    def schedule_email(self):
        """Schedule emails based on the selected interval"""
        try:
            interval_value = int(self.interval_value.get())
            interval_unit = self.interval_unit.get()
            
            if interval_unit == "seconds":
                self.interval_seconds = interval_value
            elif interval_unit == "minutes":
                self.interval_seconds = interval_value * 60
            else:  # hours
                self.interval_seconds = interval_value * 3600
                
            self.log_message(f"Email automation started: Every {interval_value} {interval_unit}")
            return True
                
        except ValueError:
            self.log_message("Error: Interval value must be a number")
            return False
        
    def run_scheduler(self):
        """Run the scheduler in a separate thread"""
        self.schedule_running = True
        self.update_next_send_time()
        last_sent = 0
        
        while self.schedule_running:
            current_time = time.time()
            if current_time - last_sent >= self.interval_seconds:
                self.send_email()
                last_sent = current_time
                self.update_next_send_time()
            
            time.sleep(1)
            
    def start_automation(self):
        """Start the email automation"""
        if not self.schedule_email():
            return
            
        # Disable start button, enable stop button
        self.start_button.config(state='disabled')
        self.stop_button.config(state='normal')
        self.status_var.set("Status: Running")
        
        # Start scheduler in a separate thread
        self.scheduler_thread = threading.Thread(target=self.run_scheduler)
        self.scheduler_thread.daemon = True
        self.scheduler_thread.start()
        
    def stop_automation(self):
        """Stop the email automation"""
        self.schedule_running = False
        
        # Enable start button, disable stop button
        self.start_button.config(state='normal')
        self.stop_button.config(state='disabled')
        self.status_var.set("Status: Stopped")
        self.next_send_var.set("Next send: Not scheduled")
        self.log_message("Email automation stopped")
        
    def save_config(self):
        """Save the current configuration to a file"""
        config = {
            'sender_email': self.sender_email.get(),
            'password': self.password.get(),
            'smtp_server': self.smtp_server.get(),
            'smtp_port': self.smtp_port.get(),
            'recipient_email': self.recipient_email.get(),
            'subject': self.subject.get(),
            'body': self.body.get('1.0', 'end-1c'),
            'interval_value': self.interval_value.get(),
            'interval_unit': self.interval_unit.get(),
        }
        
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f)
            self.log_message("Configuration saved successfully")
            messagebox.showinfo("Success", "Configuration saved successfully!")
        except Exception as e:
            self.log_message(f"Error saving configuration: {str(e)}")
            messagebox.showerror("Error", f"Failed to save configuration: {str(e)}")
            
    def load_config(self):
        """Load configuration from file if it exists"""
        config = {}
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            except Exception as e:
                print(f"Error loading configuration: {str(e)}")
        return config
                
    def on_closing(self):
        """Handle application closing"""
        if self.schedule_running:
            self.stop_automation()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = EmailAutomater(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()