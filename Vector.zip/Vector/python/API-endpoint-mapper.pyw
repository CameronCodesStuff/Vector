#!/usr/bin/env python3
"""
API Endpoint Mapper – Ethical Discovery Tool
FOR EDUCATIONAL AND AUTHORIZED TESTING ONLY.

This tool crawls a web application to detect REST and GraphQL endpoints,
maps routes, identifies authentication requirements, and uncovers hidden
admin APIs. It does NOT attempt to exploit any vulnerabilities.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import queue
import time
import re
import json
from urllib.parse import urljoin, urlparse, parse_qs

import requests
from bs4 import BeautifulSoup

# ===================== Configuration =====================
TIMEOUT = 10
DEFAULT_DELAY = 0.5
DEFAULT_MAX_PAGES = 50
USER_AGENT = "Mozilla/5.0 (API Mapper)"


# Common API paths to fuzz
COMMON_API_PATHS = [
    # RESTful patterns
    "api", "api/v1", "api/v2", "api/v3",
    "rest", "rest/v1", "rest/v2",
    "swagger", "swagger-ui", "api-docs", "docs",
    "graphql", "graphiql", "gql",
    "users", "user", "profile", "accounts",
    "products", "items", "posts", "articles",
    "admin", "administrator", "private", "internal",
    "config", "configuration", "settings",
    "health", "healthcheck", "status", "metrics",
    "login", "logout", "auth", "authenticate",
    "search", "query",
    "upload", "download", "files",
    "ws", "websocket", "socket.io",
    "odata", "odata/v1",
]

# Common GraphQL queries to detect endpoint
GRAPHQL_TEST_QUERY = {"query": "{__typename}"}
GRAPHQL_RESPONSE_INDICATORS = ["data", "errors", "__typename"]

# Authentication indicators in response body
AUTH_INDICATORS = [
    "unauthorized", "forbidden", "access denied",
    "authentication required", "login required",
    "invalid token", "missing token", "api key required"
]


# ===================== Helper Functions =====================
def is_same_domain(url, base_domain):
    return urlparse(url).netloc == base_domain


def normalize_url(url):
    """Remove fragments and trailing slash for consistency."""
    parsed = urlparse(url)
    path = parsed.path.rstrip('/') if parsed.path != '/' else '/'
    return f"{parsed.scheme}://{parsed.netloc}{path}"


def get(url, delay, headers=None):
    """Make a GET request with rate limiting."""
    try:
        if headers is None:
            headers = {"User-Agent": USER_AGENT}
        r = requests.get(url, timeout=TIMEOUT, headers=headers)
        time.sleep(delay)
        return r
    except Exception:
        return None


def post(url, data, delay, headers=None):
    """Make a POST request."""
    try:
        if headers is None:
            headers = {"User-Agent": USER_AGENT}
        r = requests.post(url, timeout=TIMEOUT, headers=headers, json=data)
        time.sleep(delay)
        return r
    except Exception:
        return None


# ===================== Scanner Class =====================
class APIMapper:
    def __init__(self, base_url, options, log_queue, result_queue):
        self.base_url = normalize_url(base_url)
        self.base_domain = urlparse(base_url).netloc
        self.options = options          # dict: delay, max_pages, fuzz_paths, etc.
        self.log_queue = log_queue
        self.result_queue = result_queue

        self.visited_pages = set()       # crawled HTML pages
        self.discovered_endpoints = set() # unique API endpoints found
        self.findings = []                # stored for export
        self.stop_flag = False

    def log(self, msg):
        self.log_queue.put(msg)

    def add_finding(self, endpoint, method, status, auth_required, endpoint_type, notes=""):
        """Store an endpoint finding and send to GUI."""
        finding = {
            "endpoint": endpoint,
            "method": method,
            "status": status,
            "auth_required": auth_required,
            "type": endpoint_type,
            "notes": notes,
        }
        self.findings.append(finding)
        self.result_queue.put(finding)

    def stop(self):
        self.stop_flag = True

    # -------------------- Main Orchestration --------------------
    def run(self):
        self.log(f"Starting API mapping on {self.base_url}")
        self.log(f"Domain restricted to: {self.base_domain}")

        # 1. Crawl the website to find links and JS files
        self.crawl_website()

        # 2. Parse JavaScript files for API calls
        self.parse_javascript_files()

        # 3. Fuzz common API paths
        if self.options.get("fuzz_paths", True):
            self.fuzz_api_paths()

        # 4. For each discovered endpoint, test methods and detect GraphQL
        self.analyze_endpoints()

        self.log("API mapping completed.")

    # -------------------- Crawler --------------------
    def crawl_website(self):
        """Crawl HTML pages within the same domain."""
        to_visit = [self.base_url]
        max_pages = self.options.get("max_pages", DEFAULT_MAX_PAGES)
        delay = self.options.get("delay", DEFAULT_DELAY)

        while to_visit and len(self.visited_pages) < max_pages and not self.stop_flag:
            url = to_visit.pop(0)
            if url in self.visited_pages:
                continue
            if not is_same_domain(url, self.base_domain):
                continue

            self.visited_pages.add(url)
            self.log(f"[Crawl] {url}")

            response = get(url, delay)
            if not response:
                continue

            # Look for JavaScript file URLs
            soup = BeautifulSoup(response.text, "html.parser")
            for script in soup.find_all("script", src=True):
                js_url = urljoin(url, script["src"])
                if is_same_domain(js_url, self.base_domain):
                    self.discovered_endpoints.add(js_url)  # we'll parse JS later

            # Extract links for further crawling
            for link in soup.find_all("a", href=True):
                full = urljoin(url, link["href"])
                if is_same_domain(full, self.base_domain) and full not in self.visited_pages:
                    to_visit.append(full)

    # -------------------- JavaScript Parsing --------------------
    def parse_javascript_files(self):
        """Analyze JavaScript files for fetch/XHR calls."""
        delay = self.options.get("delay", DEFAULT_DELAY)
        for js_url in list(self.discovered_endpoints):
            if self.stop_flag:
                break
            if not js_url.endswith(".js"):
                continue
            self.log(f"[JS] Parsing {js_url}")
            response = get(js_url, delay)
            if not response:
                continue
            content = response.text

            # Simple regex to find strings that look like API endpoints
            # Match quoted strings containing common API patterns
            patterns = [
                r'["\'](/api/[^"\']*)["\']',
                r'["\'](/v\d+/[^"\']*)["\']',
                r'["\'](/graphql)[^"\']*["\']',
                r'["\'](/rest/[^"\']*)["\']',
                r'["\'](/users?)[^"\']*["\']',
                r'fetch\(["\']([^"\']+)["\']\)',
                r'XMLHttpRequest\([^,]*,\s*["\']([^"\']+)["\']\)',
            ]
            for pat in patterns:
                matches = re.findall(pat, content)
                for match in matches:
                    # Construct absolute URL
                    endpoint = urljoin(self.base_url, match)
                    if is_same_domain(endpoint, self.base_domain):
                        self.discovered_endpoints.add(endpoint)
                        self.log(f"  [Found in JS] {endpoint}")

    # -------------------- API Path Fuzzing --------------------
    def fuzz_api_paths(self):
        """Test common API paths under the base URL."""
        delay = self.options.get("delay", DEFAULT_DELAY)
        base = self.base_url.rstrip('/')
        paths_to_try = COMMON_API_PATHS

        # Also try deeper paths: /api/v1/users etc. (simple combinations)
        deeper_paths = []
        for p in paths_to_try:
            deeper_paths.append(p)
            if p.startswith("api/"):
                # already deep
                pass
            elif p == "api":
                deeper_paths.append("api/users")
                deeper_paths.append("api/products")
                deeper_paths.append("api/v1/users")
                deeper_paths.append("api/v2/users")
            elif p == "admin":
                deeper_paths.append("admin/api")
                deeper_paths.append("admin/users")
        paths_to_try = list(set(deeper_paths + paths_to_try))

        for path in paths_to_try:
            if self.stop_flag:
                break
            test_url = f"{base}/{path.lstrip('/')}"
            # Normalize to avoid duplicates
            test_url = normalize_url(test_url)
            if test_url in self.discovered_endpoints:
                continue

            self.log(f"[Fuzz] Testing {test_url}")
            response = get(test_url, delay)
            if response and response.status_code < 500:
                # Any 2xx, 3xx, 4xx (except 404) indicates the endpoint exists
                if response.status_code != 404:
                    self.discovered_endpoints.add(test_url)
                    self.log(f"  -> Found ({response.status_code})")
                # Also check if it's a GraphQL endpoint (we'll analyze later)
            # Small delay between fuzz requests
            time.sleep(delay)

    # -------------------- Endpoint Analysis --------------------
    def analyze_endpoints(self):
        """For each discovered endpoint, test HTTP methods and detect GraphQL."""
        delay = self.options.get("delay", DEFAULT_DELAY)
        endpoints = list(self.discovered_endpoints)
        for endpoint in endpoints:
            if self.stop_flag:
                break
            self.log(f"[Analyze] {endpoint}")

            # Test GET
            self.test_method(endpoint, "GET", delay)

            # Test POST (with empty or generic data)
            self.test_method(endpoint, "POST", delay, data={})

            # Test PUT, DELETE, PATCH, OPTIONS
            for method in ["PUT", "DELETE", "PATCH", "OPTIONS"]:
                self.test_method(endpoint, method, delay)

            # Special GraphQL detection
            self.detect_graphql(endpoint, delay)

    def test_method(self, endpoint, method, delay, data=None):
        """Test a specific HTTP method and record result."""
        headers = {"User-Agent": USER_AGENT}
        try:
            if method == "GET":
                r = requests.get(endpoint, timeout=TIMEOUT, headers=headers)
            elif method == "POST":
                if data is not None:
                    r = requests.post(endpoint, timeout=TIMEOUT, headers=headers, json=data)
                else:
                    r = requests.post(endpoint, timeout=TIMEOUT, headers=headers)
            elif method == "PUT":
                r = requests.put(endpoint, timeout=TIMEOUT, headers=headers)
            elif method == "DELETE":
                r = requests.delete(endpoint, timeout=TIMEOUT, headers=headers)
            elif method == "PATCH":
                r = requests.patch(endpoint, timeout=TIMEOUT, headers=headers)
            elif method == "OPTIONS":
                r = requests.options(endpoint, timeout=TIMEOUT, headers=headers)
            else:
                return
            time.sleep(delay)

            # Determine if authentication is required
            auth_required = self.check_auth_required(r)

            # Determine endpoint type (REST/GraphQL/other)
            endpoint_type = self.classify_response(r, method, endpoint)

            # Only report if we got a meaningful response (not 404)
            if r.status_code != 404:
                self.add_finding(
                    endpoint=endpoint,
                    method=method,
                    status=r.status_code,
                    auth_required=auth_required,
                    endpoint_type=endpoint_type,
                    notes=f"Response size: {len(r.text)}"
                )
        except Exception as e:
            # Timeout or connection error – ignore
            pass

    def check_auth_required(self, response):
        """Determine if the response indicates authentication is needed."""
        if response.status_code in (401, 403):
            return "Yes"
        # Check body for auth indicators
        body = response.text.lower()
        for ind in AUTH_INDICATORS:
            if ind in body:
                return "Likely"
        return "No"

    def classify_response(self, response, method, endpoint):
        """Try to classify the endpoint type based on response."""
        content_type = response.headers.get("Content-Type", "")
        # GraphQL detection: if it's a GraphQL endpoint, the response often contains "data" or "errors"
        if "graphql" in endpoint.lower() or "/graphql" in endpoint:
            return "GraphQL"
        if response.status_code == 200 and "application/json" in content_type:
            try:
                data = response.json()
                if isinstance(data, dict):
                    if "data" in data or "errors" in data:
                        return "GraphQL"
                    # Probably REST JSON
                    return "REST (JSON)"
            except:
                pass
        if "application/json" in content_type:
            return "REST (JSON)"
        if "text/html" in content_type:
            return "Web Page"
        if "text/plain" in content_type:
            return "Plain Text"
        return "Unknown"

    def detect_graphql(self, endpoint, delay):
        """Send a simple introspection query to see if it's a GraphQL endpoint."""
        # Only test if endpoint looks like GraphQL or we haven't classified it yet
        if not ("graphql" in endpoint.lower() or "/graphql" in endpoint):
            # Still test a few common GraphQL paths
            if not any(p in endpoint for p in ["/api", "/v1", "/v2"]):
                return

        test_payload = {"query": "{__typename}"}
        try:
            r = requests.post(endpoint, json=test_payload, timeout=TIMEOUT,
                              headers={"User-Agent": USER_AGENT, "Content-Type": "application/json"})
            time.sleep(delay)
            if r.status_code == 200:
                try:
                    data = r.json()
                    if "data" in data or "errors" in data:
                        # It's a GraphQL endpoint!
                        auth = self.check_auth_required(r)
                        self.add_finding(
                            endpoint=endpoint,
                            method="POST",
                            status=r.status_code,
                            auth_required=auth,
                            endpoint_type="GraphQL (confirmed)",
                            notes="Responds to __typename query"
                        )
                except:
                    pass
        except Exception:
            pass


# ===================== GUI Application =====================
class APIMapperGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("API Endpoint Mapper")
        self.root.geometry("1200x700")
        self.style = ttk.Style()
        self.style.theme_use("clam")

        # Control variables
        self.url_var = tk.StringVar()
        self.max_pages_var = tk.IntVar(value=DEFAULT_MAX_PAGES)
        self.delay_var = tk.DoubleVar(value=DEFAULT_DELAY)

        # Options
        self.fuzz_paths_var = tk.BooleanVar(value=True)
        self.parse_js_var = tk.BooleanVar(value=True)

        # Threading
        self.mapper = None
        self.thread = None
        self.log_queue = queue.Queue()
        self.result_queue = queue.Queue()
        self.running = False

        self.build_ui()
        self.update_ui()

    def build_ui(self):
        # Top frame: URL and controls
        top_frame = ttk.Frame(self.root, padding="5")
        top_frame.pack(fill=tk.X)

        ttk.Label(top_frame, text="Target URL:").grid(row=0, column=0, sticky=tk.W)
        ttk.Entry(top_frame, textvariable=self.url_var, width=60).grid(row=0, column=1, padx=5)
        self.start_btn = ttk.Button(top_frame, text="Start Mapping", command=self.start_mapping)
        self.start_btn.grid(row=0, column=2, padx=5)
        self.stop_btn = ttk.Button(top_frame, text="Stop", command=self.stop_mapping, state=tk.DISABLED)
        self.stop_btn.grid(row=0, column=3, padx=5)
        self.export_btn = ttk.Button(top_frame, text="Export Report", command=self.export_report, state=tk.DISABLED)
        self.export_btn.grid(row=0, column=4, padx=5)

        # Options frame
        opts_frame = ttk.LabelFrame(self.root, text="Options", padding="5")
        opts_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(opts_frame, text="Max pages:").grid(row=0, column=0, sticky=tk.W)
        ttk.Spinbox(opts_frame, from_=10, to=500, textvariable=self.max_pages_var, width=8).grid(row=0, column=1, sticky=tk.W, padx=5)
        ttk.Label(opts_frame, text="Delay (s):").grid(row=0, column=2, sticky=tk.W, padx=(20,0))
        ttk.Spinbox(opts_frame, from_=0.1, to=5.0, increment=0.1, textvariable=self.delay_var, width=8).grid(row=0, column=3, sticky=tk.W, padx=5)

        ttk.Checkbutton(opts_frame, text="Fuzz common API paths", variable=self.fuzz_paths_var).grid(row=1, column=0, columnspan=2, sticky=tk.W)
        ttk.Checkbutton(opts_frame, text="Parse JavaScript files", variable=self.parse_js_var).grid(row=1, column=2, columnspan=2, sticky=tk.W)

        # Progress bar
        self.progress = ttk.Progressbar(self.root, mode='indeterminate')
        self.progress.pack(fill=tk.X, padx=5, pady=5)

        # Notebook for results and log
        nb = ttk.Notebook(self.root)
        nb.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Results treeview
        tree_frame = ttk.Frame(nb)
        nb.add(tree_frame, text="Discovered Endpoints")

        columns = ("Endpoint", "Method", "Status", "Auth Required", "Type", "Notes")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("Endpoint", text="Endpoint")
        self.tree.heading("Method", text="Method")
        self.tree.heading("Status", text="Status")
        self.tree.heading("Auth Required", text="Auth Required")
        self.tree.heading("Type", text="Type")
        self.tree.heading("Notes", text="Notes")

        self.tree.column("Endpoint", width=350)
        self.tree.column("Method", width=70)
        self.tree.column("Status", width=60)
        self.tree.column("Auth Required", width=100)
        self.tree.column("Type", width=150)
        self.tree.column("Notes", width=200)

        vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        # Log area
        log_frame = ttk.Frame(nb)
        nb.add(log_frame, text="Log")

        self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W).pack(fill=tk.X, side=tk.BOTTOM)

    def log(self, msg):
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)

    def update_ui(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self.log(msg)
        except queue.Empty:
            pass

        try:
            while True:
                finding = self.result_queue.get_nowait()
                self.add_finding_to_tree(finding)
        except queue.Empty:
            pass

        if self.running and self.thread and not self.thread.is_alive():
            self.mapping_finished()

        self.root.after(100, self.update_ui)

    def add_finding_to_tree(self, finding):
        # Colour rows by auth required
        auth = finding["auth_required"]
        if auth == "Yes":
            tag = "auth_yes"
        elif auth == "Likely":
            tag = "auth_likely"
        else:
            tag = "auth_no"
        self.tree.insert("", tk.END, values=(
            finding["endpoint"],
            finding["method"],
            finding["status"],
            finding["auth_required"],
            finding["type"],
            finding["notes"]
        ), tags=(tag,))

        self.tree.tag_configure("auth_yes", background="#ffcccc")
        self.tree.tag_configure("auth_likely", background="#ffe6cc")
        self.tree.tag_configure("auth_no", background="#e6f2ff")

    def start_mapping(self):
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a URL.")
            return
        if not url.startswith(("http://", "https://")):
            messagebox.showerror("Error", "URL must start with http:// or https://")
            return

        # Clear previous results
        self.tree.delete(*self.tree.get_children())
        self.log_text.delete(1.0, tk.END)
        self.export_btn.config(state=tk.DISABLED)

        options = {
            "max_pages": self.max_pages_var.get(),
            "delay": self.delay_var.get(),
            "fuzz_paths": self.fuzz_paths_var.get(),
            "parse_js": self.parse_js_var.get(),
        }

        self.mapper = APIMapper(url, options, self.log_queue, self.result_queue)

        self.running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start()

        self.thread = threading.Thread(target=self.mapper.run, daemon=True)
        self.thread.start()

        self.status_var.set("Mapping...")

    def stop_mapping(self):
        if self.mapper:
            self.mapper.stop()
        self.status_var.set("Stopping...")

    def mapping_finished(self):
        self.running = False
        self.progress.stop()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.export_btn.config(state=tk.NORMAL if self.mapper and self.mapper.findings else tk.DISABLED)
        self.status_var.set("Mapping completed.")

    def export_report(self):
        if not self.mapper or not self.mapper.findings:
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not filename:
            return

        try:
            with open(filename, "w") as f:
                f.write("=== API Endpoint Mapping Report ===\n")
                f.write(f"Target: {self.url_var.get()}\n")
                f.write(f"Date: {time.ctime()}\n\n")
                for idx, finding in enumerate(self.mapper.findings, 1):
                    f.write(f"[{idx}] {finding['endpoint']}\n")
                    f.write(f"  Method: {finding['method']}\n")
                    f.write(f"  Status: {finding['status']}\n")
                    f.write(f"  Auth Required: {finding['auth_required']}\n")
                    f.write(f"  Type: {finding['type']}\n")
                    f.write(f"  Notes: {finding['notes']}\n")
                    f.write("-" * 50 + "\n")
            messagebox.showinfo("Export", f"Report saved to {filename}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))


# ===================== Main =====================
if __name__ == "__main__":
    root = tk.Tk()
    app = APIMapperGUI(root)
    root.mainloop()