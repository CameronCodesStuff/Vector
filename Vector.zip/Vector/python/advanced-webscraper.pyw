#!/usr/bin/env python3
"""
Advanced Web Scraper GUI with Beautiful Soup
A comprehensive web scraping tool with a modern GUI interface
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import threading
import json
import os
from datetime import datetime
import webbrowser

class WebScraperGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Web Scraper")
        self.root.geometry("1000x700")
        self.root.configure(bg='#2c3e50')
        
        # Configure style
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.configure_styles()
        
        self.create_widgets()
        self.scraped_data = {}
        
    def configure_styles(self):
        """Configure modern styling for the application"""
        self.style.configure('Title.TLabel', 
                           background='#34495e', 
                           foreground='#ecf0f1', 
                           font=('Arial', 16, 'bold'))
        
        self.style.configure('Custom.TButton',
                           background='#3498db',
                           foreground='white',
                           borderwidth=1,
                           focuscolor='none')
        
        self.style.configure('Custom.TFrame',
                           background='#2c3e50')
        
        self.style.configure('Custom.TLabelframe',
                           background='#34495e',
                           foreground='#ecf0f1')
        
        self.style.configure('Custom.TLabelframe.Label',
                           background='#34495e',
                           foreground='#ecf0f1')
        
        self.style.map('Custom.TButton',
                      background=[('active', '#2980b9')])

    def create_widgets(self):
        """Create and arrange all GUI widgets"""
        # Main container
        main_frame = ttk.Frame(self.root, style='Custom.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title
        title_label = ttk.Label(main_frame, text="Advanced Web Scraper", 
                               style='Title.TLabel')
        title_label.pack(pady=(0, 20))
        
        # URL Input Section
        url_frame = ttk.LabelFrame(main_frame, text="Website URL", 
                                  style='Custom.TLabelframe')
        url_frame.pack(fill=tk.X, pady=(0, 10))
        
        url_input_frame = ttk.Frame(url_frame, style='Custom.TFrame')
        url_input_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(url_input_frame, text="Enter URL:", 
                 background='#34495e', foreground='#ecf0f1').pack(side=tk.LEFT)
        
        self.url_entry = ttk.Entry(url_input_frame, width=80)
        self.url_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        self.url_entry.insert(0, "https://")
        
        # Scraping Options Section
        options_frame = ttk.LabelFrame(main_frame, text="Scraping Options", 
                                      style='Custom.TLabelframe')
        options_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Checkboxes for content types
        self.links_var = tk.BooleanVar(value=True)
        self.images_var = tk.BooleanVar(value=True)
        self.videos_var = tk.BooleanVar(value=True)
        self.pdfs_var = tk.BooleanVar(value=True)
        self.keywords_var = tk.BooleanVar(value=True)
        self.meta_var = tk.BooleanVar(value=True)
        self.tables_var = tk.BooleanVar(value=False)
        
        checkboxes_frame = ttk.Frame(options_frame, style='Custom.TFrame')
        checkboxes_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Checkbutton(checkboxes_frame, text="Links", 
                       variable=self.links_var).grid(row=0, column=0, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="Images", 
                       variable=self.images_var).grid(row=0, column=1, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="Videos", 
                       variable=self.videos_var).grid(row=0, column=2, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="PDFs", 
                       variable=self.pdfs_var).grid(row=0, column=3, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="Keywords", 
                       variable=self.keywords_var).grid(row=1, column=0, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="Meta Tags", 
                       variable=self.meta_var).grid(row=1, column=1, sticky='w', padx=5)
        ttk.Checkbutton(checkboxes_frame, text="Tables", 
                       variable=self.tables_var).grid(row=1, column=2, sticky='w', padx=5)
        
        # Keywords input
        keywords_frame = ttk.Frame(options_frame, style='Custom.TFrame')
        keywords_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(keywords_frame, text="Keywords (comma-separated):", 
                 background='#34495e', foreground='#ecf0f1').pack(side=tk.LEFT)
        
        self.keywords_entry = ttk.Entry(keywords_frame, width=60)
        self.keywords_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        self.keywords_entry.insert(0, "python,web,scraping,data")
        
        # Control Buttons
        button_frame = ttk.Frame(main_frame, style='Custom.TFrame')
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.scrape_button = ttk.Button(button_frame, text="Start Scraping", 
                                       command=self.start_scraping,
                                       style='Custom.TButton')
        self.scrape_button.pack(side=tk.LEFT, padx=5)
        
        self.clear_button = ttk.Button(button_frame, text="Clear Results", 
                                      command=self.clear_results,
                                      style='Custom.TButton')
        self.clear_button.pack(side=tk.LEFT, padx=5)
        
        self.export_button = ttk.Button(button_frame, text="Export Data", 
                                       command=self.export_data,
                                       style='Custom.TButton')
        self.export_button.pack(side=tk.LEFT, padx=5)
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.pack(fill=tk.X, pady=(0, 10))
        
        # Results Display
        results_frame = ttk.LabelFrame(main_frame, text="Scraping Results", 
                                      style='Custom.TLabelframe')
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create notebook for different result types
        self.notebook = ttk.Notebook(results_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create tabs for different content types
        self.create_result_tabs()
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready to scrape...")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, 
                              relief=tk.SUNKEN, style='Custom.TLabel')
        status_bar.pack(fill=tk.X, pady=(5, 0))

    def create_result_tabs(self):
        """Create tabs for different types of scraped content"""
        # Summary tab
        self.summary_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.summary_text, text="Summary")
        
        # Links tab
        self.links_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.links_text, text="Links")
        
        # Images tab
        self.images_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.images_text, text="Images")
        
        # Videos tab
        self.videos_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.videos_text, text="Videos")
        
        # PDFs tab
        self.pdfs_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.pdfs_text, text="PDFs")
        
        # Keywords tab
        self.keywords_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.keywords_text, text="Keywords")
        
        # Meta Tags tab
        self.meta_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.meta_text, text="Meta Tags")
        
        # Tables tab
        self.tables_text = scrolledtext.ScrolledText(self.notebook, height=10, wrap=tk.WORD)
        self.notebook.add(self.tables_text, text="Tables")

    def start_scraping(self):
        """Start the scraping process in a separate thread"""
        url = self.url_entry.get().strip()
        if not url or url == "https://":
            messagebox.showerror("Error", "Please enter a valid URL")
            return
        
        # Validate URL
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        # Disable buttons and start progress bar
        self.scrape_button.config(state='disabled')
        self.progress.start(10)
        self.status_var.set("Scraping in progress...")
        
        # Start scraping in separate thread
        thread = threading.Thread(target=self.scrape_website, args=(url,))
        thread.daemon = True
        thread.start()

    def scrape_website(self, url):
        """Main scraping function"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            base_url = response.url
            
            # Initialize scraped data
            self.scraped_data = {
                'url': url,
                'title': soup.title.string if soup.title else 'No title',
                'timestamp': datetime.now().isoformat(),
                'links': [],
                'images': [],
                'videos': [],
                'pdfs': [],
                'keywords_found': [],
                'meta_tags': {},
                'tables': []
            }
            
            # Perform selected scraping operations
            if self.links_var.get():
                self.scrape_links(soup, base_url)
            
            if self.images_var.get():
                self.scrape_images(soup, base_url)
            
            if self.videos_var.get():
                self.scrape_videos(soup, base_url)
            
            if self.pdfs_var.get():
                self.scrape_pdfs(soup, base_url)
            
            if self.keywords_var.get():
                self.search_keywords(soup)
            
            if self.meta_var.get():
                self.scrape_meta_tags(soup)
            
            if self.tables_var.get():
                self.scrape_tables(soup)
            
            # Update GUI in main thread
            self.root.after(0, self.display_results)
            
        except Exception as e:
            self.root.after(0, lambda: self.handle_error(str(e)))
        finally:
            self.root.after(0, self.scraping_finished)

    def scrape_links(self, soup, base_url):
        """Extract all links from the page"""
        links = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            full_url = urljoin(base_url, href)
            text = link.get_text(strip=True)
            links.append({
                'url': full_url,
                'text': text,
                'title': link.get('title', '')
            })
        self.scraped_data['links'] = links

    def scrape_images(self, soup, base_url):
        """Extract all images from the page"""
        images = []
        for img in soup.find_all('img', src=True):
            src = img['src']
            full_url = urljoin(base_url, src)
            images.append({
                'url': full_url,
                'alt': img.get('alt', ''),
                'title': img.get('title', '')
            })
        self.scraped_data['images'] = images

    def scrape_videos(self, soup, base_url):
        """Extract video elements from the page"""
        videos = []
        # Look for video tags
        for video in soup.find_all('video'):
            src = video.get('src')
            if src:
                full_url = urljoin(base_url, src)
                videos.append({
                    'url': full_url,
                    'type': 'video',
                    'poster': video.get('poster', '')
                })
        
        # Look for iframes (YouTube, Vimeo, etc.)
        for iframe in soup.find_all('iframe', src=True):
            src = iframe['src']
            if any(domain in src for domain in ['youtube', 'vimeo', 'dailymotion']):
                videos.append({
                    'url': src,
                    'type': 'embedded',
                    'platform': 'YouTube/Vimeo'
                })
        
        self.scraped_data['videos'] = videos

    def scrape_pdfs(self, soup, base_url):
        """Extract PDF links from the page"""
        pdfs = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            if href.lower().endswith('.pdf'):
                full_url = urljoin(base_url, href)
                pdfs.append({
                    'url': full_url,
                    'text': link.get_text(strip=True)
                })
        self.scraped_data['pdfs'] = pdfs

    def search_keywords(self, soup):
        """Search for specified keywords in the page content"""
        keywords_text = self.keywords_entry.get().strip()
        if not keywords_text:
            return
        
        keywords = [k.strip().lower() for k in keywords_text.split(',')]
        text_content = soup.get_text().lower()
        
        found_keywords = []
        for keyword in keywords:
            if keyword and keyword in text_content:
                found_keywords.append(keyword)
        
        self.scraped_data['keywords_found'] = found_keywords

    def scrape_meta_tags(self, soup):
        """Extract meta tags from the page"""
        meta_tags = {}
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property')
            content = meta.get('content')
            if name and content:
                meta_tags[name] = content
        self.scraped_data['meta_tags'] = meta_tags

    def scrape_tables(self, soup):
        """Extract tables from the page"""
        tables = []
        for i, table in enumerate(soup.find_all('table')):
            table_data = []
            for row in table.find_all('tr'):
                row_data = []
                for cell in row.find_all(['td', 'th']):
                    row_data.append(cell.get_text(strip=True))
                if row_data:
                    table_data.append(row_data)
            if table_data:
                tables.append({
                    'index': i,
                    'data': table_data
                })
        self.scraped_data['tables'] = tables

    def display_results(self):
        """Display scraped results in the GUI"""
        # Clear all text widgets
        for widget in [self.summary_text, self.links_text, self.images_text, 
                      self.videos_text, self.pdfs_text, self.keywords_text,
                      self.meta_text, self.tables_text]:
            widget.delete(1.0, tk.END)
        
        # Display summary
        summary = f"""Scraping Results for: {self.scraped_data['url']}
Title: {self.scraped_data['title']}
Scraped at: {self.scraped_data['timestamp']}

Summary:
- Links found: {len(self.scraped_data['links'])}
- Images found: {len(self.scraped_data['images'])}
- Videos found: {len(self.scraped_data['videos'])}
- PDFs found: {len(self.scraped_data['pdfs'])}
- Keywords found: {len(self.scraped_data['keywords_found'])}
- Meta tags found: {len(self.scraped_data['meta_tags'])}
- Tables found: {len(self.scraped_data['tables'])}
"""
        self.summary_text.insert(tk.END, summary)
        
        # Display links
        for link in self.scraped_data['links']:
            self.links_text.insert(tk.END, f"Text: {link['text']}\n")
            self.links_text.insert(tk.END, f"URL: {link['url']}\n")
            if link['title']:
                self.links_text.insert(tk.END, f"Title: {link['title']}\n")
            self.links_text.insert(tk.END, "-" * 50 + "\n")
        
        # Display images
        for img in self.scraped_data['images']:
            self.images_text.insert(tk.END, f"URL: {img['url']}\n")
            if img['alt']:
                self.images_text.insert(tk.END, f"Alt: {img['alt']}\n")
            if img['title']:
                self.images_text.insert(tk.END, f"Title: {img['title']}\n")
            self.images_text.insert(tk.END, "-" * 50 + "\n")
        
        # Display videos
        for video in self.scraped_data['videos']:
            self.videos_text.insert(tk.END, f"URL: {video['url']}\n")
            self.videos_text.insert(tk.END, f"Type: {video['type']}\n")
            if video.get('platform'):
                self.videos_text.insert(tk.END, f"Platform: {video['platform']}\n")
            self.videos_text.insert(tk.END, "-" * 50 + "\n")
        
        # Display PDFs
        for pdf in self.scraped_data['pdfs']:
            self.pdfs_text.insert(tk.END, f"Text: {pdf['text']}\n")
            self.pdfs_text.insert(tk.END, f"URL: {pdf['url']}\n")
            self.pdfs_text.insert(tk.END, "-" * 50 + "\n")
        
        # Display keywords
        if self.scraped_data['keywords_found']:
            self.keywords_text.insert(tk.END, "Found keywords:\n")
            for keyword in self.scraped_data['keywords_found']:
                self.keywords_text.insert(tk.END, f"- {keyword}\n")
        else:
            self.keywords_text.insert(tk.END, "No specified keywords found\n")
        
        # Display meta tags
        for name, content in self.scraped_data['meta_tags'].items():
            self.meta_text.insert(tk.END, f"{name}: {content}\n")
        
        # Display tables
        for table in self.scraped_data['tables']:
            self.tables_text.insert(tk.END, f"Table {table['index'] + 1}:\n")
            for row in table['data']:
                self.tables_text.insert(tk.END, " | ".join(row) + "\n")
            self.tables_text.insert(tk.END, "-" * 50 + "\n")

    def handle_error(self, error_message):
        """Handle scraping errors"""
        messagebox.showerror("Scraping Error", f"An error occurred:\n{error_message}")

    def scraping_finished(self):
        """Clean up after scraping is finished"""
        self.progress.stop()
        self.scrape_button.config(state='normal')
        self.status_var.set("Scraping completed!")

    def clear_results(self):
        """Clear all results"""
        for widget in [self.summary_text, self.links_text, self.images_text, 
                      self.videos_text, self.pdfs_text, self.keywords_text,
                      self.meta_text, self.tables_text]:
            widget.delete(1.0, tk.END)
        
        self.scraped_data = {}
        self.status_var.set("Results cleared")

    def export_data(self):
        """Export scraped data to JSON file"""
        if not self.scraped_data:
            messagebox.showwarning("No Data", "No data to export. Please scrape a website first.")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(self.scraped_data, f, indent=2, ensure_ascii=False)
                messagebox.showinfo("Success", f"Data exported to {filename}")
            except Exception as e:
                messagebox.showerror("Export Error", f"Failed to export data:\n{str(e)}")

def install_dependencies():
    """Install required dependencies"""
    import subprocess
    import sys
    
    packages = ['requests', 'beautifulsoup4', 'lxml']
    
    for package in packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])

def main():
    """Main function to run the application"""
    # Install dependencies
    print("Checking and installing dependencies...")
    install_dependencies()
    print("Dependencies installed successfully!")
    
    # Create and run GUI
    root = tk.Tk()
    app = WebScraperGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()