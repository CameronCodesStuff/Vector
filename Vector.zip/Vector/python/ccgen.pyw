import tkinter as tk
from tkinter import ttk, messagebox
import random
import sys

# Check if faker is installed
try:
    from faker import Faker
except ImportError:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(
        "Missing Library",
        "The 'faker' library is required.\nPlease install it with: pip install faker"
    )
    sys.exit(1)


class CreditCardGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Credit Card Generator")
        self.root.geometry("700x600")
        self.root.resizable(False, False)

        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TLabel", font=("Segoe UI", 10))
        self.style.configure("TButton", font=("Segoe UI", 10, "bold"))
        self.style.configure("TEntry", font=("Segoe UI", 10))

        # Countries and their Faker locale codes
        self.countries = {
            "United States": "en_US",
            "United Kingdom": "en_GB",
            "Canada": "en_CA",
            "France": "fr_FR",
            "Germany": "de_DE",
            "Australia": "en_AU",
            "Spain": "es_ES",
            "Italy": "it_IT",
            "Japan": "ja_JP",
            "New Zealand": "en_NZ",
            "India": "en_IN",
        }

        # Card types supported by Faker
        self.card_types = [
            ("visa", 3),
            ("mastercard", 3),
            ("amex", 4),          # "amex" not "american_express"
            ("discover", 3),
        ]

        # Common email domains
        self.email_domains = ["gmail.com", "outlook.com", "yahoo.com", "hotmail.com", "aol.com"]

        self.create_widgets()
        self.generate_card()  # initial card

    def create_widgets(self):
        mainframe = ttk.Frame(self.root, padding="20")
        mainframe.pack(fill=tk.BOTH, expand=True)

        # Top control frame
        control_frame = ttk.Frame(mainframe)
        control_frame.pack(fill=tk.X, pady=(0, 20))

        ttk.Label(control_frame, text="Country:").pack(side=tk.LEFT, padx=(0, 5))
        self.country_var = tk.StringVar()
        self.country_combo = ttk.Combobox(
            control_frame,
            textvariable=self.country_var,
            values=list(self.countries.keys()),
            state="readonly",
            width=20,
        )
        self.country_combo.pack(side=tk.LEFT, padx=(0, 20))
        self.country_combo.current(0)

        self.generate_btn = ttk.Button(
            control_frame, text="Generate New Card", command=self.generate_card
        )
        self.generate_btn.pack(side=tk.LEFT)

        # Card details frame
        details_frame = ttk.LabelFrame(mainframe, text="Card Details", padding="15")
        details_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        fields = [
            ("Card Type:", "card_type"),
            ("Card Number:", "card_number"),
            ("Expiry (MM/YY):", "expiry"),
            ("CVV:", "cvv"),
            ("Full Name:", "name"),
            ("Address:", "address"),
            ("Postcode:", "postcode"),
            ("Country:", "country"),
            ("Phone:", "phone"),
            ("Email:", "email"),
        ]

        self.entries = {}
        for i, (label_text, key) in enumerate(fields):
            ttk.Label(details_frame, text=label_text).grid(
                row=i, column=0, sticky="w", pady=5, padx=(0, 10)
            )
            entry = ttk.Entry(details_frame, width=50, state="readonly")
            entry.grid(row=i, column=1, sticky="ew", pady=5)
            self.entries[key] = entry

        details_frame.columnconfigure(1, weight=1)

        # Bottom button frame
        bottom_frame = ttk.Frame(mainframe)
        bottom_frame.pack(fill=tk.X)

        self.copy_btn = ttk.Button(
            bottom_frame, text="Copy All to Clipboard", command=self.copy_all
        )
        self.copy_btn.pack(side=tk.RIGHT)

        # Status bar
        self.status = ttk.Label(mainframe, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status.pack(fill=tk.X, pady=(10, 0))

    def generate_card(self):
        """Generate a new fake credit card and update the display."""
        try:
            # Get selected country and locale
            country_name = self.country_var.get()
            locale = self.countries[country_name]

            # Create a Faker instance for the chosen locale
            fake = Faker(locale)

            # Randomly select a card type
            card_type, cvv_length = random.choice(self.card_types)

            # Generate card number and format
            raw_number = fake.credit_card_number(card_type=card_type)
            formatted_number = " ".join(
                [raw_number[i:i+4] for i in range(0, len(raw_number), 4)]
            )

            expiry = fake.credit_card_expire(start="now", end="+5y", date_format="%m/%y")
            cvv = fake.credit_card_security_code(card_type=card_type)

            # Personal details
            full_name = fake.name()
            street = fake.street_address()
            city = fake.city()

            # Include state/province if the locale supports it
            try:
                state = fake.state()
                address = f"{street}, {city}, {state}"
            except AttributeError:
                address = f"{street}, {city}"

            postcode = fake.postcode()

            # Country field: use the selected country name, not fake.country()
            country_display = country_name

            phone = fake.phone_number()

            # Generate email with a common domain
            # Create a username from the name (lowercase, replace spaces with dots)
            username = full_name.lower().replace(" ", ".")
            # Remove any apostrophes or special characters
            username = ''.join(c for c in username if c.isalnum() or c == '.')
            domain = random.choice(self.email_domains)
            email = f"{username}@{domain}"

            # Update all entry widgets
            self.entries["card_type"].config(state="normal")
            self.entries["card_type"].delete(0, tk.END)
            self.entries["card_type"].insert(0, card_type.replace("_", " ").title())
            self.entries["card_type"].config(state="readonly")

            self.entries["card_number"].config(state="normal")
            self.entries["card_number"].delete(0, tk.END)
            self.entries["card_number"].insert(0, formatted_number)
            self.entries["card_number"].config(state="readonly")

            self.entries["expiry"].config(state="normal")
            self.entries["expiry"].delete(0, tk.END)
            self.entries["expiry"].insert(0, expiry)
            self.entries["expiry"].config(state="readonly")

            self.entries["cvv"].config(state="normal")
            self.entries["cvv"].delete(0, tk.END)
            self.entries["cvv"].insert(0, cvv)
            self.entries["cvv"].config(state="readonly")

            self.entries["name"].config(state="normal")
            self.entries["name"].delete(0, tk.END)
            self.entries["name"].insert(0, full_name)
            self.entries["name"].config(state="readonly")

            self.entries["address"].config(state="normal")
            self.entries["address"].delete(0, tk.END)
            self.entries["address"].insert(0, address)
            self.entries["address"].config(state="readonly")

            self.entries["postcode"].config(state="normal")
            self.entries["postcode"].delete(0, tk.END)
            self.entries["postcode"].insert(0, postcode)
            self.entries["postcode"].config(state="readonly")

            self.entries["country"].config(state="normal")
            self.entries["country"].delete(0, tk.END)
            self.entries["country"].insert(0, country_display)
            self.entries["country"].config(state="readonly")

            self.entries["phone"].config(state="normal")
            self.entries["phone"].delete(0, tk.END)
            self.entries["phone"].insert(0, phone)
            self.entries["phone"].config(state="readonly")

            self.entries["email"].config(state="normal")
            self.entries["email"].delete(0, tk.END)
            self.entries["email"].insert(0, email)
            self.entries["email"].config(state="readonly")

            self.status.config(text=f"Card generated for {country_name}")

        except Exception as e:
            messagebox.showerror("Generation Error", f"Could not generate card:\n{e}")
            self.status.config(text="Error generating card")

    def copy_all(self):
        """Copy all card details to the clipboard in a formatted block."""
        details = []
        label_map = {
            "card_type": "Card Type",
            "card_number": "Card Number",
            "expiry": "Expiry",
            "cvv": "CVV",
            "name": "Name",
            "address": "Address",
            "postcode": "Postcode",
            "country": "Country",
            "phone": "Phone",
            "email": "Email",
        }
        for key, entry in self.entries.items():
            label = label_map.get(key, key)
            value = entry.get()
            details.append(f"{label}: {value}")

        text = "\n".join(details)
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.status.config(text="Details copied to clipboard!")


if __name__ == "__main__":
    root = tk.Tk()
    app = CreditCardGenerator(root)
    root.mainloop()