import json
import os
import secrets
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from eth_account import Account
from web3 import Web3

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------
INFURA_PROJECT_ID = '4a648f5a448a478a877f56e755c6cda3'   # <-- Replace with your ID
NETWORK = 'sepolia'                            # testnet
ACCOUNTS_FILE = 'wallet_accounts.json'

# Connect to Ethereum node via Infura
w3 = Web3(Web3.HTTPProvider(f'https://{NETWORK}.infura.io/v3/{INFURA_PROJECT_ID}'))
if not w3.is_connected():
    raise Exception("Failed to connect to Ethereum network. Check your Infura ID.")

# ----------------------------------------------------------------------
# Wallet Manager Class (unchanged from your version)
# ----------------------------------------------------------------------
class WalletManager:
    def __init__(self, accounts_file=ACCOUNTS_FILE):
        self.accounts_file = accounts_file
        self.accounts = {}      # address -> private key
        self.load_accounts()

    def load_accounts(self):
        if os.path.exists(self.accounts_file):
            with open(self.accounts_file, 'r') as f:
                self.accounts = json.load(f)
        else:
            self.accounts = {}

    def save_accounts(self):
        with open(self.accounts_file, 'w') as f:
            json.dump(self.accounts, f, indent=4)

    def generate_account(self):
        private_key = "0x" + secrets.token_hex(32)
        account = Account.from_key(private_key)
        address = account.address
        self.accounts[address] = private_key
        self.save_accounts()
        return address, private_key

    def import_account(self, private_key):
        account = Account.from_key(private_key)
        address = account.address
        self.accounts[address] = private_key
        self.save_accounts()
        return address

    def get_balance(self, address):
        try:
            wei_balance = w3.eth.get_balance(address)
            return w3.from_wei(wei_balance, 'ether')
        except Exception:
            return 0

    def send_eth(self, from_address, to_address, amount_eth):
        if from_address not in self.accounts:
            raise Exception("Sender address not in your wallet.")

        private_key = self.accounts[from_address]
        amount_wei = w3.to_wei(amount_eth, 'ether')
        nonce = w3.eth.get_transaction_count(from_address)
        gas_limit = 21000
        gas_price = w3.eth.gas_price

        tx = {
            'nonce': nonce,
            'to': to_address,
            'value': amount_wei,
            'gas': gas_limit,
            'gasPrice': gas_price,
            'chainId': w3.eth.chain_id
        }

        signed_tx = Account.sign_transaction(tx, private_key)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        return tx_hash.hex()

# ----------------------------------------------------------------------
# GUI Application
# ----------------------------------------------------------------------
class WalletApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ethereum Wallet (Sepolia Testnet)")
        self.root.geometry("700x500")
        self.root.resizable(True, True)

        self.wallet = WalletManager()

        # Style
        style = ttk.Style()
        style.theme_use('clam')

        # Main container
        main_frame = ttk.Frame(root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # ----- Account List Section -----
        list_frame = ttk.LabelFrame(main_frame, text="Your Accounts", padding="5")
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        # Treeview for accounts (address + balance)
        columns = ('address', 'balance')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=8)
        self.tree.heading('address', text='Address')
        self.tree.heading('balance', text='Balance (ETH)')
        self.tree.column('address', width=400)
        self.tree.column('balance', width=100, anchor='center')

        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.grid(row=0, column=0, sticky='nsew')
        scrollbar.grid(row=0, column=1, sticky='ns')
        list_frame.grid_columnconfigure(0, weight=1)
        list_frame.grid_rowconfigure(0, weight=1)

        # ----- Button Bar -----
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=5)

        ttk.Button(btn_frame, text="Generate New Account", command=self.generate_account).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Import Account", command=self.import_account).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Refresh Balances", command=self.refresh_balances).pack(side=tk.LEFT, padx=2)

        # ----- Send Transaction Section -----
        send_frame = ttk.LabelFrame(main_frame, text="Send ETH", padding="5")
        send_frame.pack(fill=tk.X, pady=5)

        # From account (dropdown)
        from_row = ttk.Frame(send_frame)
        from_row.pack(fill=tk.X, pady=2)
        ttk.Label(from_row, text="From:", width=10).pack(side=tk.LEFT)
        self.from_var = tk.StringVar()
        self.from_combo = ttk.Combobox(from_row, textvariable=self.from_var, state='readonly', width=60)
        self.from_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # To address
        to_row = ttk.Frame(send_frame)
        to_row.pack(fill=tk.X, pady=2)
        ttk.Label(to_row, text="To:", width=10).pack(side=tk.LEFT)
        self.to_entry = ttk.Entry(to_row, width=60)
        self.to_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Amount
        amount_row = ttk.Frame(send_frame)
        amount_row.pack(fill=tk.X, pady=2)
        ttk.Label(amount_row, text="Amount (ETH):", width=10).pack(side=tk.LEFT)
        self.amount_entry = ttk.Entry(amount_row, width=20)
        self.amount_entry.pack(side=tk.LEFT)
        ttk.Button(amount_row, text="Send", command=self.send_eth).pack(side=tk.LEFT, padx=10)

        # ----- Status Bar -----
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = ttk.Label(root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Populate initial data
        self.refresh_account_list()
        self.update_from_dropdown()

    # ------------------------------------------------------------------
    # Helper Methods
    # ------------------------------------------------------------------
    def refresh_account_list(self):
        """Clear and reload the treeview with current accounts and balances."""
        for row in self.tree.get_children():
            self.tree.delete(row)

        if not self.wallet.accounts:
            self.tree.insert('', tk.END, values=('No accounts stored.', ''))
            return

        for addr in self.wallet.accounts.keys():
            balance = self.wallet.get_balance(addr)
            self.tree.insert('', tk.END, values=(addr, f"{balance:.6f}"))

    def update_from_dropdown(self):
        """Update the 'From' combobox with current account addresses."""
        addresses = list(self.wallet.accounts.keys())
        self.from_combo['values'] = addresses
        if addresses:
            self.from_combo.current(0)

    def set_status(self, message, is_error=False):
        """Update status bar and optionally show error popup."""
        self.status_var.set(message)
        if is_error:
            messagebox.showerror("Error", message)
        else:
            # For long operations, we might also show a popup on success
            pass

    # ------------------------------------------------------------------
    # Action Methods (run in separate threads to avoid freezing GUI)
    # ------------------------------------------------------------------
    def generate_account(self):
        def task():
            try:
                addr, priv = self.wallet.generate_account()
                self.root.after(0, lambda: self._on_generate_success(addr, priv))
            except Exception as e:
                self.root.after(0, lambda: self.set_status(f"Generation failed: {e}", True))

        threading.Thread(target=task, daemon=True).start()
        self.set_status("Generating account...")

    def _on_generate_success(self, address, private_key):
        self.refresh_account_list()
        self.update_from_dropdown()
        # Show private key in a messagebox
        messagebox.showinfo("Account Generated",
                            f"Address: {address}\n\nPrivate Key:\n{private_key}\n\n⚠️ Store this key safely and never share it!")
        self.set_status("Account generated successfully.")

    def import_account(self):
        priv_key = simpledialog.askstring("Import Account", "Enter private key (with or without 0x):",
                                          parent=self.root)
        if not priv_key:
            return
        if not priv_key.startswith('0x'):
            priv_key = '0x' + priv_key

        def task():
            try:
                addr = self.wallet.import_account(priv_key)
                self.root.after(0, lambda: self._on_import_success(addr))
            except Exception as e:
                self.root.after(0, lambda: self.set_status(f"Import failed: {e}", True))

        threading.Thread(target=task, daemon=True).start()
        self.set_status("Importing account...")

    def _on_import_success(self, address):
        self.refresh_account_list()
        self.update_from_dropdown()
        self.set_status(f"Account {address} imported successfully.")

    def refresh_balances(self):
        def task():
            try:
                # Refresh the tree with latest balances
                self.root.after(0, self.refresh_account_list)
                self.root.after(0, lambda: self.set_status("Balances updated."))
            except Exception as e:
                self.root.after(0, lambda: self.set_status(f"Refresh failed: {e}", True))

        threading.Thread(target=task, daemon=True).start()
        self.set_status("Refreshing balances...")

    def send_eth(self):
        from_addr = self.from_var.get()
        to_addr = self.to_entry.get().strip()
        amount_str = self.amount_entry.get().strip()

        if not from_addr:
            self.set_status("Please select a sender account.", True)
            return
        if not to_addr:
            self.set_status("Please enter a recipient address.", True)
            return
        try:
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError
        except ValueError:
            self.set_status("Invalid amount. Enter a positive number.", True)
            return

        # Confirm with user
        if not messagebox.askyesno("Confirm Send",
                                   f"Send {amount} ETH from\n{from_addr}\nto\n{to_addr}?"):
            return

        def task():
            try:
                tx_hash = self.wallet.send_eth(from_addr, to_addr, amount)
                self.root.after(0, lambda: self._on_send_success(tx_hash, amount, to_addr))
            except Exception as e:
                self.root.after(0, lambda: self.set_status(f"Send failed: {e}", True))

        threading.Thread(target=task, daemon=True).start()
        self.set_status("Sending transaction...")

    def _on_send_success(self, tx_hash, amount, to_addr):
        # Refresh balances to show updated amount
        self.refresh_account_list()
        self.set_status(f"Sent {amount} ETH to {to_addr} successfully. Tx: {tx_hash[:10]}...")
        messagebox.showinfo("Transaction Sent",
                            f"Transaction hash:\n{tx_hash}\n\nView on Etherscan:\n"
                            f"https://sepolia.etherscan.io/tx/{tx_hash}")

# ----------------------------------------------------------------------
# Run the application
# ----------------------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = WalletApp(root)
    root.mainloop()